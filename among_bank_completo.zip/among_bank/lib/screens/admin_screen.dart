import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_state.dart';
import '../models/user_model.dart';
import '../widgets/theme.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
    context.read<AppState>().refreshAll();
  }

  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final me = state.currentUser!;

    if (!me.canViewAdmin) {
      return Scaffold(
        backgroundColor: kBg,
        body: const Center(child: Text('❌ Sin permisos', style: TextStyle(color: Colors.red, fontSize: 18))),
      );
    }

    final tabs = [
      const Tab(text: '👥 Usuarios'),
      const Tab(text: '💰 SC'),
      if (me.isSuperAdmin || me.isLiderSupremo) const Tab(text: '🏦 Banco'),
    ];

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: const Text('👑 Panel Admin'),
        backgroundColor: kBg,
        bottom: TabBar(
          controller: _tabs,
          indicatorColor: kGold,
          labelColor: kGold,
          unselectedLabelColor: Colors.white38,
          tabs: tabs,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: kGold),
            onPressed: () => state.refreshAll(),
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          _UsersTab(loading: _loading, setLoading: (v) => setState(() => _loading = v)),
          _SCTab(loading: _loading, setLoading: (v) => setState(() => _loading = v)),
          if (me.isSuperAdmin || me.isLiderSupremo)
            _BankTab(loading: _loading, setLoading: (v) => setState(() => _loading = v)),
        ],
      ),
    );
  }
}

// ── TAB USUARIOS ───────────────────────────────────────────────
class _UsersTab extends StatefulWidget {
  final bool loading;
  final Function(bool) setLoading;
  const _UsersTab({required this.loading, required this.setLoading});
  @override
  State<_UsersTab> createState() => _UsersTabState();
}

class _UsersTabState extends State<_UsersTab> {
  final _nameCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  String _roleSelected = 'tripulante';
  bool _showForm = false;

  @override
  void dispose() { _nameCtrl.dispose(); _passCtrl.dispose(); super.dispose(); }

  Future<void> _createUser() async {
    if (_nameCtrl.text.trim().isEmpty || _passCtrl.text.trim().isEmpty) {
      showMsg(context, '❌ Completá nombre y contraseña', isError: true); return;
    }
    widget.setLoading(true);
    final result = await context.read<AppState>().createUser(
        _nameCtrl.text.trim(), _passCtrl.text.trim(), _roleSelected);
    if (!mounted) return;
    widget.setLoading(false);
    showMsg(context, result, isError: !result.startsWith('✅'));
    if (result.startsWith('✅')) {
      setState(() { _showForm = false; _nameCtrl.clear(); _passCtrl.clear(); });
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final me = state.currentUser!;
    final users = state.users;
    final fmt = NumberFormat('#,##0', 'es');

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // CREAR USUARIO
        if (me.canCreateUsers) ...[
          GoldButton(
            label: _showForm ? 'Cancelar' : '➕ Crear nuevo usuario',
            onTap: () => setState(() => _showForm = !_showForm),
          ),
          if (_showForm) ...[
            const SizedBox(height: 16),
            SectionCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Nuevo usuario', style: TextStyle(color: kGold, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _nameCtrl,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(labelText: 'Nombre de usuario'),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _passCtrl,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(labelText: 'Contraseña'),
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: _roleSelected,
                    dropdownColor: kCard,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(labelText: 'Rol'),
                    items: const [
                      DropdownMenuItem(value: 'tripulante', child: Text('🚀 Tripulante')),
                      DropdownMenuItem(value: 'admin', child: Text('🟢 Admin')),
                      DropdownMenuItem(value: 'admin_elite', child: Text('💜 Admin Elite')),
                      DropdownMenuItem(value: 'colider', child: Text('🔵 Co-Líder')),
                      DropdownMenuItem(value: 'lider_supremo', child: Text('⭐ Líder Supremo')),
                    ],
                    onChanged: (v) => setState(() => _roleSelected = v!),
                  ),
                  const SizedBox(height: 16),
                  GoldButton(label: 'Crear usuario', loading: widget.loading, onTap: _createUser, icon: Icons.person_add),
                ],
              ),
            ),
          ],
          const SizedBox(height: 16),
        ],

        // LISTA DE USUARIOS
        const Text('Usuarios del clan', style: TextStyle(color: Colors.white54, fontSize: 13)),
        const SizedBox(height: 8),
        ...users.map((u) => _UserTile(user: u, me: me, fmt: fmt,
            loading: widget.loading, setLoading: widget.setLoading)),
      ],
    );
  }
}

class _UserTile extends StatelessWidget {
  final UserModel user;
  final UserModel me;
  final NumberFormat fmt;
  final bool loading;
  final Function(bool) setLoading;

  const _UserTile({required this.user, required this.me, required this.fmt,
      required this.loading, required this.setLoading});

  bool get _isPrivileged => user.id == 'lautaro_superadmin' || user.id == 'itzel_lider';
  bool get _isMe => user.id == me.id;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _isMe ? kGold.withOpacity(0.4) : Colors.white10),
      ),
      child: ExpansionTile(
        leading: CircleAvatar(
          backgroundColor: user.isActive ? roleColor(user.role).withOpacity(0.2) : Colors.red.withOpacity(0.2),
          child: Text(user.avatarInitials ?? user.name[0].toUpperCase(),
              style: TextStyle(color: user.isActive ? roleColor(user.role) : Colors.red,
                  fontWeight: FontWeight.bold)),
        ),
        title: Text(user.name,
            style: TextStyle(color: _isMe ? kGold : Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
        subtitle: Text('${user.roleLabel} • ${user.isActive ? "Activo" : "Suspendido"} • \$${fmt.format(user.balance)} SC',
            style: const TextStyle(color: Colors.white38, fontSize: 11)),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(
              children: [
                StatRow(label: 'Score', value: '⭐ ${user.score.toInt()}'),
                StatRow(label: 'Tarjeta', value: user.cardType),
                StatRow(label: 'Logros', value: '${user.achievements.length}'),
                if (!_isPrivileged && !_isMe) ...[
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      if (me.canSuspendUsers)
                        _AdminChip(
                          label: user.isActive ? '🚫 Suspender' : '✅ Activar',
                          color: user.isActive ? Colors.red : Colors.green,
                          onTap: () async {
                            setLoading(true);
                            final result = user.isActive
                                ? await context.read<AppState>().suspendUser(user.id)
                                : await context.read<AppState>().activateUser(user.id);
                            if (context.mounted) { setLoading(false); showMsg(context, result, isError: !result.startsWith('✅')); }
                          },
                        ),
                      if (me.canModifyRoles)
                        _AdminChip(
                          label: '🔄 Cambiar rol',
                          color: Colors.blue,
                          onTap: () => _showRoleDialog(context),
                        ),
                      if (me.canDeleteUsers)
                        _AdminChip(
                          label: '🗑️ Eliminar',
                          color: Colors.red[700]!,
                          onTap: () => _confirmDelete(context),
                        ),
                    ],
                  ),
                ],
                if (_isPrivileged)
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text('👑 Usuario privilegiado — protegido',
                        style: TextStyle(color: kGold, fontSize: 11)),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showRoleDialog(BuildContext context) {
    showDialog(context: context, builder: (_) {
      String sel = user.role;
      return StatefulBuilder(builder: (ctx, setSt) {
        return AlertDialog(
          backgroundColor: kCard,
          title: Text('Cambiar rol de ${user.name}', style: const TextStyle(color: Colors.white, fontSize: 15)),
          content: DropdownButton<String>(
            value: sel,
            dropdownColor: kCard,
            style: const TextStyle(color: Colors.white),
            items: const [
              DropdownMenuItem(value: 'tripulante', child: Text('🚀 Tripulante')),
              DropdownMenuItem(value: 'admin', child: Text('🟢 Admin')),
              DropdownMenuItem(value: 'admin_elite', child: Text('💜 Admin Elite')),
              DropdownMenuItem(value: 'colider', child: Text('🔵 Co-Líder')),
              DropdownMenuItem(value: 'lider_supremo', child: Text('⭐ Líder Supremo')),
            ],
            onChanged: (v) => setSt(() => sel = v!),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar', style: TextStyle(color: Colors.white54))),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: kGold),
              onPressed: () async {
                Navigator.pop(ctx);
                setLoading(true);
                final result = await context.read<AppState>().changeRole(user.id, sel);
                if (context.mounted) { setLoading(false); showMsg(context, result, isError: !result.startsWith('✅')); }
              },
              child: const Text('Guardar', style: TextStyle(color: Colors.black)),
            ),
          ],
        );
      });
    });
  }

  void _confirmDelete(BuildContext context) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: kCard,
      title: const Text('¿Eliminar usuario?', style: TextStyle(color: Colors.white)),
      content: Text('Se eliminará a ${user.name} permanentemente.', style: const TextStyle(color: Colors.white70)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar', style: TextStyle(color: Colors.white54))),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          onPressed: () async {
            Navigator.pop(context);
            setLoading(true);
            final result = await context.read<AppState>().deleteUser(user.id);
            if (context.mounted) { setLoading(false); showMsg(context, result, isError: !result.startsWith('✅')); }
          },
          child: const Text('Eliminar', style: TextStyle(color: Colors.white)),
        ),
      ],
    ));
  }
}

class _AdminChip extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _AdminChip({required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.4)),
        ),
        child: Text(label, style: TextStyle(color: color, fontSize: 12)),
      ),
    );
  }
}

// ── TAB SC ─────────────────────────────────────────────────────
class _SCTab extends StatefulWidget {
  final bool loading;
  final Function(bool) setLoading;
  const _SCTab({required this.loading, required this.setLoading});
  @override
  State<_SCTab> createState() => _SCTabState();
}

class _SCTabState extends State<_SCTab> {
  UserModel? _target;
  final _amtCtrl = TextEditingController();

  @override
  void dispose() { _amtCtrl.dispose(); super.dispose(); }

  Future<void> _load(bool add) async {
    if (_target == null) { showMsg(context, '❌ Seleccioná un usuario', isError: true); return; }
    final amount = double.tryParse(_amtCtrl.text.replaceAll(',', '.'));
    if (amount == null || amount <= 0) { showMsg(context, '❌ Monto inválido', isError: true); return; }

    widget.setLoading(true);
    String result;
    if (add) {
      result = await context.read<AppState>().loadSC(_target!.id, amount);
    } else {
      result = await context.read<AppState>().adjustBalance(_target!.id, -amount);
    }
    if (!mounted) return;
    widget.setLoading(false);
    showMsg(context, result, isError: !result.startsWith('✅'));
    _amtCtrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final me = state.currentUser!;
    final users = state.users.where((u) => u.isActive).toList();
    final fmt = NumberFormat('#,##0', 'es');

    if (!me.canLoadSC) {
      return const Center(child: Text('❌ Sin permisos para gestionar SC', style: TextStyle(color: Colors.red)));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          SectionCard(
            child: StatRow(
              label: '🏦 Banco Central',
              value: '\$${fmt.format(state.bankBalance)} SC',
              valueColor: kGold,
            ),
          ),
          const SizedBox(height: 20),
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Usuario destinatario', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                DropdownButtonFormField<UserModel>(
                  value: _target,
                  dropdownColor: kCard,
                  decoration: const InputDecoration(labelText: 'Seleccioná usuario'),
                  style: const TextStyle(color: Colors.white),
                  items: users.map((u) => DropdownMenuItem(
                    value: u,
                    child: Text('${u.name} (${u.roleLabel}) — \$${fmt.format(u.balance)} SC',
                        style: const TextStyle(fontSize: 12)),
                  )).toList(),
                  onChanged: (v) => setState(() => _target = v),
                ),
                const SizedBox(height: 12),
                AmountField(controller: _amtCtrl, label: 'Cantidad de SC'),
                const SizedBox(height: 8),
                Wrap(spacing: 8, children: [100, 500, 1000, 5000, 10000].map((v) =>
                  ActionChip(
                    label: Text('\$$v'),
                    backgroundColor: kCard2,
                    labelStyle: const TextStyle(color: kGold, fontSize: 11),
                    onPressed: () => _amtCtrl.text = '$v',
                  )).toList()),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: GoldButton(
                        label: '➕ Agregar SC',
                        loading: widget.loading,
                        onTap: () => _load(true),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GestureDetector(
                        onTap: widget.loading ? null : () => _load(false),
                        child: Container(
                          height: 52,
                          decoration: BoxDecoration(
                            color: Colors.red.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: Colors.red.withOpacity(0.4)),
                          ),
                          child: const Center(
                            child: Text('➖ Quitar SC',
                                style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          // RANKING RÁPIDO
          const Text('Estado de SC por usuario', style: TextStyle(color: Colors.white54, fontSize: 13)),
          const SizedBox(height: 8),
          ...state.rankingByBalance.map((u) => ListTile(
            leading: CircleAvatar(
              backgroundColor: kGold.withOpacity(0.1),
              child: Text(u.avatarInitials ?? u.name[0], style: const TextStyle(color: kGold, fontWeight: FontWeight.bold)),
            ),
            title: Text(u.name, style: const TextStyle(color: Colors.white, fontSize: 13)),
            subtitle: Text(u.roleLabel, style: const TextStyle(color: Colors.white38, fontSize: 11)),
            trailing: Text('\$${fmt.format(u.balance)} SC',
                style: const TextStyle(color: kGold, fontWeight: FontWeight.bold)),
          )),
        ],
      ),
    );
  }
}

// ── TAB BANCO CENTRAL ──────────────────────────────────────────
class _BankTab extends StatefulWidget {
  final bool loading;
  final Function(bool) setLoading;
  const _BankTab({required this.loading, required this.setLoading});
  @override
  State<_BankTab> createState() => _BankTabState();
}

class _BankTabState extends State<_BankTab> {
  final _rechargeCtrl = TextEditingController();

  @override
  void dispose() { _rechargeCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final me = state.currentUser!;
    final stats = state.getStats();
    final fmt = NumberFormat('#,##0', 'es');

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // BANCO CENTRAL
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [kGold.withOpacity(0.15), kGoldDark.withOpacity(0.1)]),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: kGold.withOpacity(0.3)),
            ),
            child: Column(
              children: [
                const Text('🏦 BANCO CENTRAL', style: TextStyle(color: kGold, fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 1)),
                const SizedBox(height: 16),
                Text('\$${fmt.format(state.bankBalance)} SC',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 32)),
                const Text('Saldo disponible', style: TextStyle(color: Colors.white38, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // ESTADÍSTICAS
          SectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('📊 Estadísticas', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                StatRow(label: 'Total usuarios', value: '${stats['totalUsuarios']}'),
                StatRow(label: 'Usuarios activos', value: '${stats['usuariosActivos']}'),
                StatRow(label: 'SC en circulación', value: '\$${fmt.format(stats['totalSC'])} SC', valueColor: Colors.green),
                StatRow(label: 'Banco Central', value: '\$${fmt.format(stats['bancoCentral'])} SC', valueColor: kGold),
              ],
            ),
          ),

          // RECARGAR BANCO (solo super_admin)
          if (me.canRechargeBank) ...[
            const SizedBox(height: 20),
            SectionCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('💉 Recargar Banco Central', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  AmountField(controller: _rechargeCtrl, label: 'Cantidad a agregar'),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, children: [10000, 50000, 100000, 500000].map((v) =>
                    ActionChip(
                      label: Text('\$${fmt.format(v.toDouble())}'),
                      backgroundColor: kCard2,
                      labelStyle: const TextStyle(color: kGold, fontSize: 11),
                      onPressed: () => _rechargeCtrl.text = '$v',
                    )).toList()),
                  const SizedBox(height: 12),
                  GoldButton(
                    label: '💰 Recargar Banco',
                    loading: widget.loading,
                    onTap: () async {
                      final amount = double.tryParse(_rechargeCtrl.text.replaceAll(',', '.'));
                      if (amount == null || amount <= 0) {
                        showMsg(context, '❌ Monto inválido', isError: true); return;
                      }
                      widget.setLoading(true);
                      final result = await context.read<AppState>().rechargeBank(amount);
                      if (!mounted) return;
                      widget.setLoading(false);
                      showMsg(context, result, isError: !result.startsWith('✅'));
                      _rechargeCtrl.clear();
                    },
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
