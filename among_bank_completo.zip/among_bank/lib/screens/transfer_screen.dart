import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_state.dart';
import '../models/user_model.dart';
import '../widgets/theme.dart';

class TransferScreen extends StatefulWidget {
  const TransferScreen({super.key});
  @override
  State<TransferScreen> createState() => _TransferScreenState();
}

class _TransferScreenState extends State<TransferScreen> {
  final _amountCtrl = TextEditingController();
  UserModel? _selected;
  bool _loading = false;
  bool _done = false;
  String _lastMsg = '';

  @override
  void dispose() { _amountCtrl.dispose(); super.dispose(); }

  Future<void> _transfer() async {
    if (_selected == null) {
      showMsg(context, '❌ Seleccioná un destinatario', isError: true); return;
    }
    final amount = double.tryParse(_amountCtrl.text.replaceAll(',', '.'));
    if (amount == null || amount <= 0) {
      showMsg(context, '❌ Monto inválido', isError: true); return;
    }

    setState(() => _loading = true);
    final state = context.read<AppState>();
    final result = await state.transfer(_selected!.id, amount);
    if (!mounted) return;
    setState(() { _loading = false; _lastMsg = result; });

    if (result.startsWith('✅')) {
      setState(() => _done = true);
    } else {
      showMsg(context, result, isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final user = state.currentUser!;
    final others = state.users.where((u) => u.id != user.id && u.isActive).toList();
    final fmt = NumberFormat('#,##0.00', 'es');

    if (_done) {
      return Scaffold(
        backgroundColor: kBg,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('✅', style: TextStyle(fontSize: 80)),
              const SizedBox(height: 20),
              const Text('¡Transferencia completada!',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 22)),
              const SizedBox(height: 12),
              Text(_lastMsg, style: const TextStyle(color: Colors.white54)),
              const SizedBox(height: 8),
              Text('Para: ${_selected!.name}',
                  style: const TextStyle(color: kGold, fontSize: 16)),
              Text('\$${fmt.format(double.tryParse(_amountCtrl.text.replaceAll(',', '.')) ?? 0)} SC',
                  style: const TextStyle(color: kGold, fontWeight: FontWeight.bold, fontSize: 28)),
              const SizedBox(height: 40),
              GoldButton(
                label: 'Nueva transferencia',
                onTap: () => setState(() { _done = false; _selected = null; _amountCtrl.clear(); }),
              ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Volver', style: TextStyle(color: Colors.white54)),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text('💸 Transferir'), backgroundColor: kBg),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionCard(
              child: StatRow(
                label: 'Tu saldo disponible',
                value: '\$${fmt.format(user.balance)} SC',
                valueColor: kGold,
              ),
            ),
            const SizedBox(height: 24),
            const Text('Destinatario', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            if (others.isEmpty)
              const SectionCard(child: Center(child: Text('No hay otros usuarios disponibles', style: TextStyle(color: Colors.white38))))
            else
              SectionCard(
                padding: EdgeInsets.zero,
                child: Column(
                  children: others.map((u) {
                    final sel = _selected?.id == u.id;
                    return ListTile(
                      onTap: () => setState(() => _selected = u),
                      leading: CircleAvatar(
                        backgroundColor: kGold.withOpacity(0.15),
                        child: Text(u.avatarInitials ?? u.name[0].toUpperCase(),
                            style: const TextStyle(color: kGold, fontWeight: FontWeight.bold)),
                      ),
                      title: Text(u.name, style: const TextStyle(color: Colors.white)),
                      subtitle: Text(u.roleLabel, style: const TextStyle(color: Colors.white38, fontSize: 11)),
                      trailing: sel
                          ? const Icon(Icons.check_circle, color: kGold)
                          : const Icon(Icons.radio_button_unchecked, color: Colors.white24),
                      tileColor: sel ? kGold.withOpacity(0.08) : null,
                    );
                  }).toList(),
                ),
              ),
            const SizedBox(height: 24),
            const Text('Cantidad', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            AmountField(controller: _amountCtrl, label: 'Cantidad de SC'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [100, 500, 1000, 2000, 5000].map((v) =>
                ActionChip(
                  label: Text('\$$v'),
                  backgroundColor: kCard2,
                  labelStyle: const TextStyle(color: kGold),
                  onPressed: () => _amountCtrl.text = '$v',
                ),
              ).toList(),
            ),
            const SizedBox(height: 32),
            GoldButton(label: 'Confirmar transferencia', loading: _loading, onTap: _transfer, icon: Icons.send),
          ],
        ),
      ),
    );
  }
}
