import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import '../services/app_state.dart';
import '../widgets/theme.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscure = true;
  bool _loading = false;
  int _fails = 0;
  bool _blocked = false;
  Timer? _blockTimer;

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    _blockTimer?.cancel();
    super.dispose();
  }

  Future<void> _login() async {
    if (_blocked) return;
    if (_userCtrl.text.trim().isEmpty || _passCtrl.text.isEmpty) {
      showMsg(context, '❌ Completá usuario y contraseña', isError: true);
      return;
    }
    setState(() => _loading = true);
    final state = context.read<AppState>();
    final error = await state.login(_userCtrl.text.trim(), _passCtrl.text);
    if (!mounted) return;
    setState(() => _loading = false);

    if (error == null) {
      _fails = 0;
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => const HomeScreen(),
          transitionsBuilder: (_, anim, __, child) =>
              FadeTransition(opacity: anim, child: child),
          transitionDuration: const Duration(milliseconds: 400),
        ),
      );
    } else {
      _fails++;
      if (_fails >= 3) {
        setState(() => _blocked = true);
        showMsg(context, '⛔ Demasiados intentos. Bloqueado 30 segundos.', isError: true);
        _blockTimer = Timer(const Duration(seconds: 30), () {
          if (mounted) setState(() { _blocked = false; _fails = 0; });
        });
      } else {
        showMsg(context, '❌ $error ($_fails/3)', isError: true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: MediaQuery.of(context).size.height - 80,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 60),
                // LOGO
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(colors: [kGold, kGoldDark]),
                    boxShadow: [BoxShadow(color: kGold.withOpacity(0.35), blurRadius: 30, spreadRadius: 5)],
                  ),
                  child: const Icon(Icons.account_balance, size: 50, color: Colors.black),
                ),
                const SizedBox(height: 20),
                const Text('Among Bank',
                    style: TextStyle(color: kGold, fontSize: 30, fontWeight: FontWeight.bold, letterSpacing: 2)),
                const SizedBox(height: 6),
                const Text('Iniciá sesión para continuar',
                    style: TextStyle(color: Colors.white54, fontSize: 13)),
                const SizedBox(height: 48),

                // USUARIO
                TextField(
                  controller: _userCtrl,
                  enabled: !_blocked && !_loading,
                  textInputAction: TextInputAction.next,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    labelText: 'Usuario',
                    prefixIcon: Icon(Icons.person_outline, color: kGold),
                  ),
                ),
                const SizedBox(height: 16),

                // CONTRASEÑA
                TextField(
                  controller: _passCtrl,
                  enabled: !_blocked && !_loading,
                  obscureText: _obscure,
                  onSubmitted: (_) => _login(),
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Contraseña',
                    prefixIcon: const Icon(Icons.lock_outline, color: kGold),
                    suffixIcon: IconButton(
                      icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility, color: Colors.grey),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                ),
                const SizedBox(height: 32),

                // BOTÓN
                GoldButton(
                  label: _blocked ? '⛔ Bloqueado temporalmente' : 'Iniciar Sesión',
                  loading: _loading,
                  onTap: _blocked ? null : _login,
                  icon: Icons.login,
                ),
                const SizedBox(height: 20),

                if (_blocked)
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.red.withOpacity(0.5)),
                    ),
                    child: const Text('⛔ Cuenta bloqueada 30 segundos por múltiples intentos fallidos',
                        style: TextStyle(color: Colors.red, fontSize: 12),
                        textAlign: TextAlign.center),
                  )
                else
                  const Text('🔒 Solo los líderes pueden crear nuevas cuentas',
                      style: TextStyle(color: Colors.white24, fontSize: 11),
                      textAlign: TextAlign.center),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
