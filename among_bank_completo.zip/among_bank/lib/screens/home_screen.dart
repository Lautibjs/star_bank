import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_state.dart';
import '../widgets/theme.dart';
import 'login_screen.dart';
import 'transfer_screen.dart';
import 'card_screen.dart';
import 'store_screen.dart';
import 'loans_screen.dart';
import 'savings_screen.dart';
import 'history_screen.dart';
import 'ranking_screen.dart';
import 'achievements_screen.dart';
import 'bonuses_screen.dart';
import 'notifications_screen.dart';
import 'admin_screen.dart';
import 'nova_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _fmt = NumberFormat('#,##0.00', 'es');
  bool _balanceVisible = true;

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 12) return '☀️ Buenos días';
    if (h < 18) return '🌤️ Buenas tardes';
    return '🌙 Buenas noches';
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final user = state.currentUser!;
    final txs = state.transactions.take(5).toList();

    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: RefreshIndicator(
          color: kGold,
          backgroundColor: kCard,
          onRefresh: () => state.refreshCurrentUser(),
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20),
                // HEADER
                Row(
                  children: [
                    CircleAvatar(
                      radius: 24,
                      backgroundColor: kGold.withOpacity(0.2),
                      child: Text(
                        user.avatarInitials ?? user.name[0].toUpperCase(),
                        style: const TextStyle(color: kGold, fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_greeting(),
                              style: const TextStyle(color: Colors.white54, fontSize: 13)),
                          Text(user.name,
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                          Text(user.roleLabel,
                              style: TextStyle(color: roleColor(user.role), fontSize: 12)),
                        ],
                      ),
                    ),
                    // NOTIFICACIONES
                    Stack(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.notifications_outlined, color: Colors.white54),
                          onPressed: () => Navigator.push(context,
                              MaterialPageRoute(builder: (_) => const NotificationsScreen())),
                        ),
                        if (state.unreadCount > 0)
                          Positioned(
                            right: 8, top: 8,
                            child: Container(
                              width: 16, height: 16,
                              decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                              child: Center(
                                child: Text('${state.unreadCount}',
                                    style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
                              ),
                            ),
                          ),
                      ],
                    ),
                    // LOGOUT
                    IconButton(
                      icon: const Icon(Icons.logout, color: Colors.white38),
                      onPressed: () async {
                        await state.logout();
                        if (mounted) {
                          Navigator.pushReplacement(context,
                              MaterialPageRoute(builder: (_) => const LoginScreen()));
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // TARJETA PRINCIPAL
                GestureDetector(
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const CardScreen())),
                  child: Container(
                    width: double.infinity,
                    height: 180,
                    decoration: BoxDecoration(
                      gradient: cardGradient(user.cardType),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [BoxShadow(color: Colors.black38, blurRadius: 20, offset: const Offset(0, 8))],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Among Bank',
                                  style: TextStyle(
                                      color: cardTextColor(user.cardType).withOpacity(0.8),
                                      fontSize: 13, letterSpacing: 1)),
                              Text(user.cardType,
                                  style: TextStyle(
                                      color: cardTextColor(user.cardType),
                                      fontWeight: FontWeight.bold, fontSize: 14)),
                            ],
                          ),
                          const Spacer(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Saldo SC',
                                      style: TextStyle(
                                          color: cardTextColor(user.cardType).withOpacity(0.7),
                                          fontSize: 11)),
                                  GestureDetector(
                                    onTap: () => setState(() => _balanceVisible = !_balanceVisible),
                                    child: Text(
                                      _balanceVisible
                                          ? '\$${_fmt.format(user.balance)}'
                                          : '••••••',
                                      style: TextStyle(
                                          color: cardTextColor(user.cardType),
                                          fontWeight: FontWeight.bold,
                                          fontSize: 26),
                                    ),
                                  ),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text('Score',
                                      style: TextStyle(
                                          color: cardTextColor(user.cardType).withOpacity(0.7),
                                          fontSize: 11)),
                                  Text('⭐ ${user.score.toInt()}',
                                      style: TextStyle(
                                          color: cardTextColor(user.cardType),
                                          fontWeight: FontWeight.bold, fontSize: 16)),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(user.name,
                              style: TextStyle(
                                  color: cardTextColor(user.cardType).withOpacity(0.8),
                                  fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // BOTONES RÁPIDOS
                const Text('Acciones', style: TextStyle(color: Colors.white54, fontSize: 13)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _ActionBtn(icon: Icons.send, label: 'Transferir', color: Colors.blue,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TransferScreen()))),
                    _ActionBtn(icon: Icons.card_giftcard, label: 'Tienda', color: Colors.purple,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StoreScreen()))),
                    _ActionBtn(icon: Icons.savings, label: 'Ahorros', color: Colors.green,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SavingsScreen()))),
                    _ActionBtn(icon: Icons.account_balance, label: 'Préstamo', color: kGold,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoansScreen()))),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _ActionBtn(icon: Icons.history, label: 'Historial', color: Colors.orange,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HistoryScreen()))),
                    _ActionBtn(icon: Icons.leaderboard, label: 'Ranking', color: Colors.red,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RankingScreen()))),
                    _ActionBtn(icon: Icons.emoji_events, label: 'Logros', color: Colors.amber,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AchievementsScreen()))),
                    _ActionBtn(icon: Icons.redeem, label: 'Bonos', color: Colors.pink,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BonusesScreen()))),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    _ActionBtn(icon: Icons.smart_toy, label: 'Nova', color: Colors.cyan,
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NovaScreen()))),
                    if (user.canViewAdmin)
                      _ActionBtn(icon: Icons.admin_panel_settings, label: 'Admin', color: Colors.red,
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen()))),
                  ],
                ),
                const SizedBox(height: 28),

                // ÚLTIMOS MOVIMIENTOS
                const Text('Últimos movimientos', style: TextStyle(color: Colors.white54, fontSize: 13)),
                const SizedBox(height: 12),
                if (txs.isEmpty)
                  SectionCard(
                    child: const Center(
                      child: Padding(
                        padding: EdgeInsets.all(20),
                        child: Text('Sin movimientos aún 💫',
                            style: TextStyle(color: Colors.white38)),
                      ),
                    ),
                  )
                else
                  SectionCard(
                    padding: EdgeInsets.zero,
                    child: Column(
                      children: txs.map((tx) {
                        final isPos = tx.amount > 0;
                        return ListTile(
                          leading: Text(tx.icon, style: const TextStyle(fontSize: 22)),
                          title: Text(tx.description,
                              style: const TextStyle(color: Colors.white, fontSize: 13)),
                          subtitle: Text(
                            DateFormat('dd/MM HH:mm').format(tx.timestamp),
                            style: const TextStyle(color: Colors.white38, fontSize: 11),
                          ),
                          trailing: Text(
                            '${isPos ? '+' : ''}\$${_fmt.format(tx.amount.abs())}',
                            style: TextStyle(
                              color: isPos ? Colors.greenAccent : Colors.redAccent,
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionBtn({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.all(4),
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(height: 6),
              Text(label,
                  style: const TextStyle(color: Colors.white70, fontSize: 11),
                  textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}
