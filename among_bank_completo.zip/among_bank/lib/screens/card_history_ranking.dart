import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_state.dart';
import '../widgets/theme.dart';

// ═══════════════════════════════════════════════════════════════
// CARD SCREEN
// ═══════════════════════════════════════════════════════════════
class CardScreen extends StatefulWidget {
  const CardScreen({super.key});
  @override
  State<CardScreen> createState() => _CardScreenState();
}

class _CardScreenState extends State<CardScreen>
    with SingleTickerProviderStateMixin {
  bool _flipped = false;
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _anim = Tween(begin: 0.0, end: 1.0).animate(_ctrl);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  void _flip() {
    if (_flipped) { _ctrl.reverse(); } else { _ctrl.forward(); }
    setState(() => _flipped = !_flipped);
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AppState>().currentUser!;
    final fmt = NumberFormat('#,##0.00', 'es');
    final cards = [
      {'Starter': '⬜', 'Blue': '🔵', 'Silver': '⚪', 'Premium': '💜',
       'Platinum': '🔘', 'Gold': '🟡', 'Ruby': '🔴', 'Black': '⬛', 'Diamond': '💎'}
    ];
    _ = cards;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: const Text('💳 Mi Tarjeta'),
        backgroundColor: kBg,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(height: 16),
            GestureDetector(
              onTap: _flip,
              child: AnimatedBuilder(
                animation: _anim,
                builder: (_, __) {
                  final angle = _anim.value * 3.14159;
                  final isFront = _anim.value < 0.5;
                  return Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()
                      ..setEntry(3, 2, 0.001)
                      ..rotateY(angle),
                    child: Container(
                      width: double.infinity,
                      height: 200,
                      decoration: BoxDecoration(
                        gradient: cardGradient(user.cardType),
                        borderRadius: BorderRadius.circular(22),
                        boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 25, offset: const Offset(0, 10))],
                      ),
                      padding: const EdgeInsets.all(24),
                      child: isFront
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text('Among Bank',
                                        style: TextStyle(color: cardTextColor(user.cardType).withOpacity(0.8), fontSize: 14, letterSpacing: 1)),
                                    Text(user.cardType,
                                        style: TextStyle(color: cardTextColor(user.cardType), fontWeight: FontWeight.bold, fontSize: 15)),
                                  ],
                                ),
                                const Spacer(),
                                Text('\$${fmt.format(user.balance)} SC',
                                    style: TextStyle(color: cardTextColor(user.cardType), fontWeight: FontWeight.bold, fontSize: 28)),
                                const SizedBox(height: 8),
                                Text(user.name,
                                    style: TextStyle(color: cardTextColor(user.cardType).withOpacity(0.85), fontSize: 14)),
                              ],
                            )
                          : Transform(
                              alignment: Alignment.center,
                              transform: Matrix4.identity()..rotateY(3.14159),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('ID Cliente', style: TextStyle(color: cardTextColor(user.cardType).withOpacity(0.7), fontSize: 12)),
                                  const SizedBox(height: 4),
                                  Text(user.id.substring(0, min(16, user.id.length)),
                                      style: TextStyle(color: cardTextColor(user.cardType), fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 2)),
                                  const SizedBox(height: 16),
                                  Text('⭐ Score: ${user.score.toInt()}',
                                      style: TextStyle(color: cardTextColor(user.cardType), fontSize: 16)),
                                  const SizedBox(height: 4),
                                  Text(user.roleLabel,
                                      style: TextStyle(color: cardTextColor(user.cardType).withOpacity(0.7), fontSize: 12)),
                                ],
                              ),
                            ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            const Text('Toca la tarjeta para girarla', style: TextStyle(color: Colors.white38, fontSize: 12)),
            const SizedBox(height: 32),
            SectionCard(
              child: Column(
                children: [
                  StatRow(label: 'Nombre', value: user.name),
                  StatRow(label: 'Tipo de tarjeta', value: user.cardType),
                  StatRow(label: 'Rol', value: user.roleLabel),
                  StatRow(label: 'Estado', value: user.isActive ? '✅ Activa' : '❌ Suspendida',
                      valueColor: user.isActive ? Colors.green : Colors.red),
                  StatRow(label: 'Score', value: '⭐ ${user.score.toInt()}', valueColor: kGold),
                  StatRow(label: 'Logros', value: '${user.achievements.length} desbloqueados', valueColor: Colors.amber),
                ],
              ),
            ),
            const SizedBox(height: 20),
            SectionCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Progreso de tarjeta', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  ..._buildCardProgress(user.balance),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildCardProgress(double balance) {
    final tiers = [
      {'name': 'Blue', 'min': 1000.0},
      {'name': 'Silver', 'min': 5000.0},
      {'name': 'Premium', 'min': 10000.0},
      {'name': 'Platinum', 'min': 20000.0},
      {'name': 'Gold', 'min': 50000.0},
      {'name': 'Ruby', 'min': 100000.0},
      {'name': 'Black', 'min': 250000.0},
      {'name': 'Diamond', 'min': 500000.0},
    ];
    final fmt = NumberFormat('#,##0', 'es');
    return tiers.map((t) {
      final min = t['min'] as double;
      final reached = balance >= min;
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Text(reached ? '✅' : '⬜', style: const TextStyle(fontSize: 14)),
            const SizedBox(width: 8),
            Expanded(child: Text('${t['name']} — \$${fmt.format(min)} SC',
                style: TextStyle(color: reached ? Colors.white : Colors.white38, fontSize: 13))),
          ],
        ),
      );
    }).toList();
  }
}

int min(int a, int b) => a < b ? a : b;

// ═══════════════════════════════════════════════════════════════
// HISTORY SCREEN
// ═══════════════════════════════════════════════════════════════
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final txs = state.transactions;
    final fmt = NumberFormat('#,##0.00', 'es');

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: const Text('📜 Historial'),
        backgroundColor: kBg,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: kGold),
            onPressed: () => state.refreshCurrentUser(),
          ),
        ],
      ),
      body: txs.isEmpty
          ? const Center(
              child: Text('Sin movimientos aún 💫',
                  style: TextStyle(color: Colors.white38, fontSize: 16)))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: txs.length,
              separatorBuilder: (_, __) =>
                  const Divider(color: Colors.white10, height: 1),
              itemBuilder: (_, i) {
                final tx = txs[i];
                final isPos = tx.amount > 0;
                return ListTile(
                  leading: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: isPos
                          ? Colors.green.withOpacity(0.15)
                          : Colors.red.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(tx.icon, style: const TextStyle(fontSize: 20)),
                    ),
                  ),
                  title: Text(tx.description,
                      style: const TextStyle(color: Colors.white, fontSize: 13)),
                  subtitle: Text(
                    DateFormat('dd/MM/yyyy HH:mm').format(tx.timestamp),
                    style: const TextStyle(color: Colors.white38, fontSize: 11),
                  ),
                  trailing: Text(
                    '${isPos ? '+' : ''}\$${fmt.format(tx.amount.abs())}',
                    style: TextStyle(
                      color: isPos ? Colors.greenAccent : Colors.redAccent,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                );
              },
            ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// RANKING SCREEN
// ═══════════════════════════════════════════════════════════════
class RankingScreen extends StatefulWidget {
  const RankingScreen({super.key});
  @override
  State<RankingScreen> createState() => _RankingScreenState();
}

class _RankingScreenState extends State<RankingScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: const Text('🏆 Ranking'),
        backgroundColor: kBg,
        bottom: TabBar(
          controller: _tabs,
          indicatorColor: kGold,
          labelColor: kGold,
          unselectedLabelColor: Colors.white38,
          tabs: const [Tab(text: '💰 Por SC'), Tab(text: '⭐ Por Score')],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          _RankingList(users: state.rankingByBalance, byBalance: true),
          _RankingList(users: state.rankingByScore, byBalance: false),
        ],
      ),
    );
  }
}

class _RankingList extends StatelessWidget {
  final List users;
  final bool byBalance;
  const _RankingList({required this.users, required this.byBalance});

  @override
  Widget build(BuildContext context) {
    final fmt = NumberFormat('#,##0', 'es');
    final medals = ['🥇', '🥈', '🥉'];
    final currentId = context.read<AppState>().currentUser?.id;

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: users.length,
      itemBuilder: (_, i) {
        final u = users[i];
        final isMe = u.id == currentId;
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: isMe ? kGold.withOpacity(0.1) : kCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: isMe ? kGold.withOpacity(0.4) : Colors.white10),
          ),
          child: Row(
            children: [
              Text(i < 3 ? medals[i] : '${i + 1}',
                  style: const TextStyle(fontSize: 18, color: Colors.white54)),
              const SizedBox(width: 12),
              CircleAvatar(
                radius: 18,
                backgroundColor: kGold.withOpacity(0.2),
                child: Text(
                  u.avatarInitials ?? u.name[0].toUpperCase(),
                  style: const TextStyle(color: kGold, fontWeight: FontWeight.bold, fontSize: 14),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(u.name,
                        style: TextStyle(
                            color: isMe ? kGold : Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14)),
                    Text(u.cardType,
                        style: const TextStyle(color: Colors.white38, fontSize: 11)),
                  ],
                ),
              ),
              Text(
                byBalance
                    ? '\$${fmt.format(u.balance)} SC'
                    : '⭐ ${fmt.format(u.score)}',
                style: TextStyle(
                    color: isMe ? kGold : Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 13),
              ),
            ],
          ),
        );
      },
    );
  }
}
