import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/app_state.dart';
import '../services/firebase_service.dart';
import '../widgets/theme.dart';

// ═══════════════════════════════════════════════════════════════
// LOANS SCREEN
// ═══════════════════════════════════════════════════════════════
class LoansScreen extends StatefulWidget {
  const LoansScreen({super.key});
  @override
  State<LoansScreen> createState() => _LoansScreenState();
}

class _LoansScreenState extends State<LoansScreen> {
  Map<String, dynamic>? _offer;
  Map<String, dynamic>? _activeLoan;
  final _payCtrl = TextEditingController();
  bool _loading = false;
  bool _offerLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() { _payCtrl.dispose(); super.dispose(); }

  Future<void> _loadData() async {
    final state = context.read<AppState>();
    final userId = state.currentUser!.id;
    final offer = await state.getLoanOffer();
    final active = await FirebaseService.getActiveLoan(userId);
    if (mounted) setState(() { _offer = offer; _activeLoan = active; _offerLoading = false; });
  }

  Future<void> _takeLoan() async {
    setState(() => _loading = true);
    final result = await context.read<AppState>().takeLoan();
    if (!mounted) return;
    showMsg(context, result, isError: !result.startsWith('✅'));
    setState(() => _loading = false);
    _loadData();
  }

  Future<void> _payLoan() async {
    final amount = double.tryParse(_payCtrl.text.replaceAll(',', '.'));
    if (amount == null || amount <= 0) {
      showMsg(context, '❌ Monto inválido', isError: true); return;
    }
    setState(() => _loading = true);
    final result = await context.read<AppState>().payLoan(amount);
    if (!mounted) return;
    showMsg(context, result, isError: !result.startsWith('✅'));
    _payCtrl.clear();
    setState(() => _loading = false);
    _loadData();
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AppState>().currentUser!;
    final fmt = NumberFormat('#,##0.00', 'es');

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text('🏦 Préstamos'), backgroundColor: kBg),
      body: _offerLoading
          ? const Center(child: CircularProgressIndicator(color: kGold))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // SALDO
                  SectionCard(
                    child: StatRow(
                      label: 'Tu saldo',
                      value: '\$${fmt.format(user.balance)} SC',
                      valueColor: kGold,
                    ),
                  ),
                  const SizedBox(height: 20),

                  if (_activeLoan != null) ...[
                    // PRÉSTAMO ACTIVO
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.orange.withOpacity(0.4)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('🏦 Préstamo activo',
                              style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 16)),
                          const SizedBox(height: 12),
                          StatRow(label: 'Monto original',
                              value: '\$${fmt.format((_activeLoan!['amount'] as num).toDouble())} SC'),
                          StatRow(label: 'Total a pagar',
                              value: '\$${fmt.format((_activeLoan!['totalToPay'] as num).toDouble())} SC',
                              valueColor: Colors.red),
                          StatRow(label: 'Pagado',
                              value: '\$${fmt.format((_activeLoan!['paid'] as num).toDouble())} SC',
                              valueColor: Colors.green),
                          StatRow(label: 'Restante',
                              value: '\$${fmt.format(((_activeLoan!['totalToPay'] as num) - (_activeLoan!['paid'] as num)).toDouble())} SC',
                              valueColor: Colors.orange),
                          const SizedBox(height: 8),
                          LinearProgressIndicator(
                            value: (_activeLoan!['paid'] as num) / (_activeLoan!['totalToPay'] as num),
                            backgroundColor: Colors.white12,
                            valueColor: const AlwaysStoppedAnimation<Color>(Colors.orange),
                          ),
                          const SizedBox(height: 16),
                          AmountField(controller: _payCtrl, label: 'Monto a pagar'),
                          const SizedBox(height: 12),
                          GoldButton(label: 'Realizar pago', loading: _loading, onTap: _payLoan, icon: Icons.payment),
                        ],
                      ),
                    ),
                  ] else if (_offer != null) ...[
                    // OFERTA DE PRÉSTAMO
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [kGold.withOpacity(0.1), Colors.green.withOpacity(0.05)]),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: kGold.withOpacity(0.3)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('💬 Nova:', style: TextStyle(color: Colors.cyan, fontSize: 12)),
                          const Text('"¡Tenés un préstamo disponible para vos!"',
                              style: TextStyle(color: Colors.white70, fontStyle: FontStyle.italic)),
                          const SizedBox(height: 16),
                          const Text('📋 Condiciones', style: TextStyle(color: kGold, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          StatRow(label: 'Monto aprobado',
                              value: '\$${fmt.format(_offer!['amount'])} SC', valueColor: kGold),
                          StatRow(label: 'Interés',
                              value: '${((_offer!['interest'] as double) * 100).toStringAsFixed(0)}%'),
                          StatRow(label: 'Total a pagar',
                              value: '\$${fmt.format(_offer!['totalToPay'])} SC', valueColor: Colors.red),
                          StatRow(label: 'Plazo', value: '${_offer!['weeks']} semanas'),
                          const SizedBox(height: 16),
                          GoldButton(label: '✅ Aceptar préstamo', loading: _loading, onTap: _takeLoan, icon: Icons.handshake),
                          const SizedBox(height: 8),
                          const Text('💡 Mejor score = mejores condiciones',
                              style: TextStyle(color: Colors.white38, fontSize: 11), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ],

                  const SizedBox(height: 20),
                  SectionCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('📊 Tu perfil crediticio',
                            style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        StatRow(label: 'Score', value: '⭐ ${user.score.toInt()}', valueColor: kGold),
                        StatRow(label: 'Tarjeta', value: user.cardType),
                        StatRow(label: 'Estado', value: user.isActive ? '✅ Activo' : '❌ Suspendido',
                            valueColor: user.isActive ? Colors.green : Colors.red),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// SAVINGS SCREEN
// ═══════════════════════════════════════════════════════════════
class SavingsScreen extends StatefulWidget {
  const SavingsScreen({super.key});
  @override
  State<SavingsScreen> createState() => _SavingsScreenState();
}

class _SavingsScreenState extends State<SavingsScreen> {
  final _depositCtrl = TextEditingController();
  final _withdrawCtrl = TextEditingController();
  Map<String, dynamic>? _savings;
  bool _loading = false;
  bool _savingsLoading = true;

  @override
  void initState() { super.initState(); _loadSavings(); }

  @override
  void dispose() { _depositCtrl.dispose(); _withdrawCtrl.dispose(); super.dispose(); }

  Future<void> _loadSavings() async {
    final userId = context.read<AppState>().currentUser!.id;
    final s = await FirebaseService.getSavings(userId);
    if (mounted) setState(() { _savings = s; _savingsLoading = false; });
  }

  Future<void> _deposit() async {
    final amount = double.tryParse(_depositCtrl.text.replaceAll(',', '.'));
    if (amount == null || amount <= 0) { showMsg(context, '❌ Monto inválido', isError: true); return; }
    setState(() => _loading = true);
    final result = await context.read<AppState>().deposit(amount);
    if (!mounted) return;
    showMsg(context, result, isError: !result.startsWith('✅'));
    _depositCtrl.clear();
    setState(() => _loading = false);
    _loadSavings();
  }

  Future<void> _withdraw() async {
    final amount = double.tryParse(_withdrawCtrl.text.replaceAll(',', '.'));
    if (amount == null || amount <= 0) { showMsg(context, '❌ Monto inválido', isError: true); return; }
    setState(() => _loading = true);
    final result = await context.read<AppState>().withdrawSavings(amount);
    if (!mounted) return;
    showMsg(context, result, isError: !result.startsWith('✅'));
    _withdrawCtrl.clear();
    setState(() => _loading = false);
    _loadSavings();
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AppState>().currentUser!;
    final fmt = NumberFormat('#,##0.00', 'es');
    final savedAmount = _savings != null ? (_savings!['amount'] as num).toDouble() : 0.0;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text('📈 Ahorros'), backgroundColor: kBg),
      body: _savingsLoading
          ? const Center(child: CircularProgressIndicator(color: kGold))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // SALDO DISPONIBLE
                  SectionCard(
                    child: Column(
                      children: [
                        StatRow(label: 'Saldo disponible', value: '\$${fmt.format(user.balance)} SC', valueColor: kGold),
                        if (_savings != null)
                          StatRow(label: 'En ahorros', value: '\$${fmt.format(savedAmount)} SC', valueColor: Colors.green),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  if (_savings != null) ...[
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.green.withOpacity(0.3)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('📈 Tu caja de ahorros',
                              style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 16)),
                          const SizedBox(height: 8),
                          StatRow(label: 'Saldo ahorrado', value: '\$${fmt.format(savedAmount)} SC', valueColor: Colors.green),
                          StatRow(label: 'Interés mensual', value: '5%', valueColor: Colors.lightGreen),
                          StatRow(label: 'Interés estimado', value: '+\$${fmt.format(savedAmount * 0.05)} SC/mes'),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    SectionCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('📤 Retirar ahorros', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 12),
                          AmountField(controller: _withdrawCtrl, label: 'Monto a retirar'),
                          const SizedBox(height: 12),
                          GoldButton(label: 'Retirar', loading: _loading, onTap: _withdraw),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  SectionCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('📥 Depositar', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        const Text('Mínimo 100 SC', style: TextStyle(color: Colors.white38, fontSize: 11)),
                        const SizedBox(height: 12),
                        AmountField(controller: _depositCtrl, label: 'Monto a depositar'),
                        const SizedBox(height: 8),
                        Wrap(spacing: 8, children: [500, 1000, 5000, 10000].map((v) =>
                          ActionChip(
                            label: Text('\$$v'),
                            backgroundColor: kCard2,
                            labelStyle: const TextStyle(color: kGold),
                            onPressed: () => _depositCtrl.text = '$v',
                          )).toList()),
                        const SizedBox(height: 12),
                        GoldButton(label: 'Depositar', loading: _loading, onTap: _deposit, icon: Icons.savings),
                        const SizedBox(height: 8),
                        const Text('💡 Tus ahorros generan 5% de interés mensual',
                            style: TextStyle(color: Colors.white38, fontSize: 11), textAlign: TextAlign.center),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// ACHIEVEMENTS SCREEN
// ═══════════════════════════════════════════════════════════════
class AchievementsScreen extends StatelessWidget {
  const AchievementsScreen({super.key});

  static const _all = [
    {'id': 'primer_millon', 'name': '💰 Primer Millón', 'desc': 'Alcanzá 1,000 SC', 'icon': '💰'},
    {'id': 'cliente_gold', 'name': '🏆 Cliente Gold', 'desc': 'Obtené la tarjeta Gold', 'icon': '🏆'},
    {'id': 'score_500', 'name': '⭐ 500 puntos', 'desc': 'Acumulá 500 puntos de score', 'icon': '⭐'},
    {'id': 'score_2000', 'name': '🌟 2000 puntos', 'desc': 'Acumulá 2,000 puntos', 'icon': '🌟'},
    {'id': 'leyenda', 'name': '👑 Leyenda', 'desc': 'Acumulá 5,000 puntos', 'icon': '👑'},
    {'id': 'black_card', 'name': '🖤 Tarjeta Black', 'desc': 'Obtené la tarjeta Black', 'icon': '🖤'},
    {'id': 'diamond_card', 'name': '💎 Tarjeta Diamond', 'desc': 'Obtené la tarjeta Diamond', 'icon': '💎'},
  ];

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AppState>().currentUser!;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text('🎖️ Logros'), backgroundColor: kBg),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _all.length,
        itemBuilder: (_, i) {
          final ach = _all[i];
          final unlocked = user.achievements.contains(ach['id']);
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: unlocked ? kGold.withOpacity(0.1) : kCard,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: unlocked ? kGold.withOpacity(0.4) : Colors.white10),
            ),
            child: Row(
              children: [
                Text(ach['icon']!, style: TextStyle(fontSize: 32, color: unlocked ? null : null,),),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(ach['name']!,
                          style: TextStyle(
                              color: unlocked ? kGold : Colors.white60,
                              fontWeight: FontWeight.bold, fontSize: 14)),
                      Text(ach['desc']!,
                          style: const TextStyle(color: Colors.white38, fontSize: 12)),
                    ],
                  ),
                ),
                if (unlocked)
                  const Icon(Icons.check_circle, color: kGold)
                else
                  const Icon(Icons.lock, color: Colors.white24, size: 20),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// BONUSES SCREEN
// ═══════════════════════════════════════════════════════════════
class BonusesScreen extends StatefulWidget {
  const BonusesScreen({super.key});
  @override
  State<BonusesScreen> createState() => _BonusesScreenState();
}

class _BonusesScreenState extends State<BonusesScreen> {
  bool _loading = false;

  final _bonuses = [
    {'key': 'daily_${DateTime.now().day}_${DateTime.now().month}_${DateTime.now().year}',
     'name': '☀️ Bono Diario', 'amount': 50.0, 'desc': 'Una vez por día'},
    {'key': 'weekly_${DateTime.now().weekOfYear}_${DateTime.now().year}',
     'name': '📅 Bono Semanal', 'amount': 200.0, 'desc': 'Una vez por semana'},
    {'key': 'monthly_${DateTime.now().month}_${DateTime.now().year}',
     'name': '🗓️ Bono Mensual', 'amount': 800.0, 'desc': 'Una vez por mes'},
    {'key': 'bienvenida', 'name': '🎉 Bono Bienvenida', 'amount': 500.0, 'desc': 'Solo una vez al registrarte'},
  ];

  Future<void> _claim(Map bonus) async {
    setState(() => _loading = true);
    final result = await context.read<AppState>().claimBonus(
        bonus['key'] as String, bonus['amount'] as double);
    if (!mounted) return;
    setState(() => _loading = false);
    showMsg(context, result, isError: !result.startsWith('✅'));
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AppState>().currentUser!;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text('🎁 Bonos'), backgroundColor: kBg),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: _bonuses.map((b) {
          final claimed = user.claimedBonuses.contains(b['key'] as String);
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: claimed ? kCard : Colors.green.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: claimed ? Colors.white10 : Colors.green.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(b['name'] as String,
                          style: TextStyle(
                              color: claimed ? Colors.white38 : Colors.white,
                              fontWeight: FontWeight.bold, fontSize: 14)),
                      Text(b['desc'] as String,
                          style: const TextStyle(color: Colors.white38, fontSize: 11)),
                      Text('+\$${(b['amount'] as double).toStringAsFixed(0)} SC',
                          style: TextStyle(
                              color: claimed ? Colors.white24 : Colors.green,
                              fontWeight: FontWeight.bold, fontSize: 16)),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                claimed
                    ? const Chip(
                        label: Text('Reclamado', style: TextStyle(color: Colors.white38, fontSize: 11)),
                        backgroundColor: Colors.white10,
                      )
                    : ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: kGold),
                        onPressed: _loading ? null : () => _claim(b),
                        child: const Text('Reclamar', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                      ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}

extension DateTimeExt on DateTime {
  int get weekOfYear {
    final startOfYear = DateTime(year, 1, 1);
    return ((difference(startOfYear).inDays) / 7).ceil();
  }
}

// ═══════════════════════════════════════════════════════════════
// NOTIFICATIONS SCREEN
// ═══════════════════════════════════════════════════════════════
class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final notifs = state.notifications;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: const Text('🔔 Notificaciones'),
        backgroundColor: kBg,
        actions: [
          TextButton(
            onPressed: () => state.markAllRead(),
            child: const Text('Marcar todo', style: TextStyle(color: kGold)),
          ),
        ],
      ),
      body: notifs.isEmpty
          ? const Center(child: Text('Sin notificaciones 🔔', style: TextStyle(color: Colors.white38)))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: notifs.length,
              separatorBuilder: (_, __) => const Divider(color: Colors.white10),
              itemBuilder: (_, i) {
                final n = notifs[i];
                final read = n['read'] == true;
                return ListTile(
                  leading: Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color: read ? Colors.white10 : kGold.withOpacity(0.15),
                      shape: BoxShape.circle,
                    ),
                    child: Center(child: Text(_notifIcon(n['type'] ?? ''), style: const TextStyle(fontSize: 20))),
                  ),
                  title: Text(n['title'] ?? '',
                      style: TextStyle(
                          color: read ? Colors.white54 : Colors.white,
                          fontWeight: read ? FontWeight.normal : FontWeight.bold,
                          fontSize: 13)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(n['message'] ?? '', style: const TextStyle(color: Colors.white38, fontSize: 12)),
                      Text(
                        n['timestamp'] != null
                            ? DateFormat('dd/MM HH:mm').format(DateTime.tryParse(n['timestamp']) ?? DateTime.now())
                            : '',
                        style: const TextStyle(color: Colors.white24, fontSize: 10),
                      ),
                    ],
                  ),
                  tileColor: read ? null : kGold.withOpacity(0.04),
                );
              },
            ),
    );
  }

  String _notifIcon(String type) {
    switch (type) {
      case 'transfer_in': return '📥';
      case 'load_sc': return '💰';
      case 'card_upgrade': return '💳';
      case 'achievement': return '🎖️';
      case 'loan_paid': return '🏦';
      case 'prize_request': return '👑';
      default: return '🔔';
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// NOVA SCREEN (chatbot)
// ═══════════════════════════════════════════════════════════════
class NovaScreen extends StatefulWidget {
  const NovaScreen({super.key});
  @override
  State<NovaScreen> createState() => _NovaScreenState();
}

class _NovaScreenState extends State<NovaScreen> {
  final List<Map<String, String>> _msgs = [];
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  bool _typing = false;

  @override
  void initState() {
    super.initState();
    final h = DateTime.now().hour;
    final greeting = h < 12 ? '¡Buenos días!' : h < 18 ? '¡Buenas tardes!' : '¡Buenas noches!';
    final user = _getUser();
    _msgs.add({'role': 'nova', 'text': '$greeting ${user?.name ?? ''} 🤖 Soy Nova, tu asistente de Among Bank. ¿En qué te ayudo hoy?'});
  }

  @override
  void dispose() { _ctrl.dispose(); _scroll.dispose(); super.dispose(); }

  dynamic _getUser() {
    try { return context.read<AppState>().currentUser; } catch (_) { return null; }
  }

  void _send() {
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    setState(() { _msgs.add({'role': 'user', 'text': text}); _typing = true; });
    _ctrl.clear();
    _scrollDown();

    Future.delayed(const Duration(milliseconds: 700), () {
      if (!mounted) return;
      final response = _respond(text.toLowerCase(), context.read<AppState>());
      setState(() { _msgs.add({'role': 'nova', 'text': response}); _typing = false; });
      _scrollDown();
    });
  }

  void _scrollDown() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.maxScrollExtent,
            duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }

  String _respond(String q, AppState state) {
    final user = state.currentUser!;
    final fmt = NumberFormat('#,##0.00', 'es');

    if (q.contains('saldo') || q.contains('dinero') || q.contains('sc')) {
      return '💰 Tu saldo actual es de \$${fmt.format(user.balance)} SC. Tarjeta: ${user.cardType}.';
    }
    if (q.contains('score') || q.contains('punto')) {
      return '⭐ Tu score es ${user.score.toInt()} puntos. Realizá transferencias, depósitos y comprá en la tienda para sumar más.';
    }
    if (q.contains('tarjeta')) {
      return '💳 Tenés la tarjeta ${user.cardType}. Para subir de nivel, aumentá tu saldo:\n• Blue: \$1,000\n• Gold: \$50,000\n• Diamond: \$500,000';
    }
    if (q.contains('transferir') || q.contains('enviar')) {
      return '💸 Para transferir, tocá "Transferir" en el inicio, elegí el destinatario e ingresá el monto.';
    }
    if (q.contains('préstamo') || q.contains('prestamo')) {
      return '🏦 Podés solicitar un préstamo en la sección "Préstamo". El monto y las condiciones dependen de tu score (${user.score.toInt()} pts).';
    }
    if (q.contains('ahorro') || q.contains('ahorrar')) {
      return '📈 En "Ahorros" podés depositar SC y ganar 5% de interés mensual. Mínimo 100 SC.';
    }
    if (q.contains('tienda') || q.contains('caja') || q.contains('premio')) {
      return '🛒 En la Tienda encontrás:\n🪐 Caja Nebula (500 SC)\n🌌 Caja Galaxy (1,000 SC)\n🌠 Caja Supernova (1,500 SC)\n👑 Premio Supremo (8,000 SC)';
    }
    if (q.contains('bono')) {
      return '🎁 Reclamá tu bono diario (50 SC), semanal (200 SC) y mensual (800 SC) en la sección Bonos.';
    }
    if (q.contains('logro') || q.contains('achievement')) {
      return '🎖️ Tus logros: ${user.achievements.isEmpty ? "Ninguno desbloqueado aún" : user.achievements.join(", ")}.\nRealiza acciones para desbloquear más.';
    }
    if (q.contains('rol') || q.contains('rango')) {
      return '👤 Tu rol actual es ${user.roleLabel}. Los roles son asignados por los líderes.';
    }
    if (q.contains('hola') || q.contains('buenas') || q.contains('hey')) {
      return '¡Hola ${user.name}! 🤖 Estoy aquí para ayudarte. Podés preguntarme sobre tu saldo, transferencias, préstamos, ahorros o la tienda.';
    }
    if (q.contains('gracias')) {
      return '¡De nada ${user.name}! 😊 ¿Hay algo más en lo que pueda ayudarte?';
    }
    return '🤖 Entendido. Podés preguntarme sobre:\n• Tu saldo o tarjeta\n• Transferencias\n• Préstamos\n• Ahorros\n• La tienda\n• Bonos o logros';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: const Row(children: [
          Text('🤖 ', style: TextStyle(fontSize: 20)),
          Text('Nova', style: TextStyle(color: Colors.cyan)),
          Text(' — Asistente', style: TextStyle(color: Colors.white38, fontSize: 13)),
        ]),
        backgroundColor: kBg,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scroll,
              padding: const EdgeInsets.all(16),
              itemCount: _msgs.length + (_typing ? 1 : 0),
              itemBuilder: (_, i) {
                if (_typing && i == _msgs.length) {
                  return _bubble({'role': 'nova', 'text': '...'}, typing: true);
                }
                return _bubble(_msgs[i]);
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            color: kCard,
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    style: const TextStyle(color: Colors.white),
                    onSubmitted: (_) => _send(),
                    decoration: const InputDecoration(
                      hintText: 'Preguntale a Nova...',
                      hintStyle: TextStyle(color: Colors.white38),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: kGold),
                  onPressed: _send,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _bubble(Map<String, String> msg, {bool typing = false}) {
    final isNova = msg['role'] == 'nova';
    return Align(
      alignment: isNova ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        decoration: BoxDecoration(
          color: isNova ? Colors.cyan.withOpacity(0.12) : kGold.withOpacity(0.15),
          borderRadius: BorderRadius.circular(16).copyWith(
            bottomLeft: isNova ? Radius.zero : null,
            bottomRight: isNova ? null : Radius.zero,
          ),
          border: Border.all(color: isNova ? Colors.cyan.withOpacity(0.3) : kGold.withOpacity(0.3)),
        ),
        child: typing
            ? const Text('●●●', style: TextStyle(color: Colors.white54, letterSpacing: 4))
            : Text(msg['text'] ?? '',
                style: const TextStyle(color: Colors.white, fontSize: 13, height: 1.5)),
      ),
    );
  }
}
