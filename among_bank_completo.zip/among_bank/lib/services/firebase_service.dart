import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';
import '../models/transaction_model.dart';

class FirebaseService {
  static final _db = FirebaseFirestore.instance;

  // ── USUARIOS ────────────────────────────────────────────────
  static Future<void> saveUser(UserModel user) async {
    await _db.collection('users').doc(user.id).set(user.toMap());
  }

  static Future<void> updateUser(UserModel user) async {
    await _db.collection('users').doc(user.id).update(user.toMap());
  }

  static Future<List<UserModel>> getAllUsers() async {
    final snap = await _db.collection('users').get();
    return snap.docs
        .map((d) => UserModel.fromMap(d.id, d.data()))
        .toList();
  }

  static Future<UserModel?> getUserById(String id) async {
    final doc = await _db.collection('users').doc(id).get();
    if (!doc.exists) return null;
    return UserModel.fromMap(doc.id, doc.data()!);
  }

  static Future<void> deleteUser(String id) async {
    await _db.collection('users').doc(id).delete();
    // Borrar transacciones del usuario
    final txSnap = await _db
        .collection('transactions')
        .where('userId', isEqualTo: id)
        .get();
    for (final d in txSnap.docs) {
      await d.reference.delete();
    }
  }

  // ── BANCO CENTRAL ────────────────────────────────────────────
  static Future<double> getBankBalance() async {
    final doc = await _db.collection('config').doc('banco_central').get();
    if (!doc.exists) return 5000000;
    return (doc.data()?['balance'] ?? 5000000).toDouble();
  }

  static Future<void> saveBankBalance(double balance) async {
    await _db.collection('config').doc('banco_central').set({
      'balance': balance,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  // ── TRANSACCIONES ────────────────────────────────────────────
  static Future<void> saveTransaction(TransactionModel tx) async {
    await _db.collection('transactions').doc(tx.id).set(tx.toMap());
  }

  static Future<List<TransactionModel>> getUserTransactions(String userId) async {
    final snap = await _db
        .collection('transactions')
        .where('userId', isEqualTo: userId)
        .orderBy('timestamp', descending: true)
        .limit(100)
        .get();
    return snap.docs
        .map((d) => TransactionModel.fromMap(d.id, d.data()))
        .toList();
  }

  static Future<List<TransactionModel>> getAllTransactions() async {
    final snap = await _db
        .collection('transactions')
        .orderBy('timestamp', descending: true)
        .limit(500)
        .get();
    return snap.docs
        .map((d) => TransactionModel.fromMap(d.id, d.data()))
        .toList();
  }

  // ── NOTIFICACIONES ───────────────────────────────────────────
  static Future<void> saveNotification({
    required String userId,
    required String title,
    required String message,
    required String type,
  }) async {
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    await _db.collection('notifications').doc(id).set({
      'userId': userId,
      'title': title,
      'message': message,
      'type': type,
      'read': false,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  static Future<List<Map<String, dynamic>>> getUserNotifications(
      String userId) async {
    final snap = await _db
        .collection('notifications')
        .where('userId', isEqualTo: userId)
        .orderBy('timestamp', descending: true)
        .limit(50)
        .get();
    return snap.docs.map((d) => {'id': d.id, ...d.data()}).toList();
  }

  static Future<void> markNotificationRead(String id) async {
    await _db.collection('notifications').doc(id).update({'read': true});
  }

  static Future<void> markAllNotificationsRead(String userId) async {
    final snap = await _db
        .collection('notifications')
        .where('userId', isEqualTo: userId)
        .where('read', isEqualTo: false)
        .get();
    for (final d in snap.docs) {
      await d.reference.update({'read': true});
    }
  }

  // ── PRÉSTAMOS ────────────────────────────────────────────────
  static Future<void> saveLoan({
    required String userId,
    required double amount,
    required double interest,
    required double totalToPay,
    required int weeks,
  }) async {
    final id = 'loan_${userId}_${DateTime.now().millisecondsSinceEpoch}';
    await _db.collection('loans').doc(id).set({
      'userId': userId,
      'amount': amount,
      'interest': interest,
      'totalToPay': totalToPay,
      'paid': 0.0,
      'weeks': weeks,
      'status': 'active',
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  static Future<Map<String, dynamic>?> getActiveLoan(String userId) async {
    final snap = await _db
        .collection('loans')
        .where('userId', isEqualTo: userId)
        .where('status', isEqualTo: 'active')
        .limit(1)
        .get();
    if (snap.docs.isEmpty) return null;
    return {'id': snap.docs.first.id, ...snap.docs.first.data()};
  }

  static Future<void> updateLoanPaid(String loanId, double paid) async {
    await _db.collection('loans').doc(loanId).update({'paid': paid});
  }

  static Future<void> closeLoan(String loanId) async {
    await _db
        .collection('loans')
        .doc(loanId)
        .update({'status': 'paid'});
  }

  // ── AHORROS ─────────────────────────────────────────────────
  static Future<void> saveSavings({
    required String userId,
    required double amount,
    required double interestRate,
  }) async {
    await _db.collection('savings').doc(userId).set({
      'userId': userId,
      'amount': amount,
      'interestRate': interestRate,
      'lastInterest': DateTime.now().toIso8601String(),
      'createdAt': DateTime.now().toIso8601String(),
    }, SetOptions(merge: true));
  }

  static Future<Map<String, dynamic>?> getSavings(String userId) async {
    final doc = await _db.collection('savings').doc(userId).get();
    if (!doc.exists) return null;
    return {'id': doc.id, ...doc.data()!};
  }

  static Future<void> updateSavingsAmount(String userId, double amount) async {
    await _db.collection('savings').doc(userId).update({
      'amount': amount,
      'lastInterest': DateTime.now().toIso8601String(),
    });
  }

  static Future<void> deleteSavings(String userId) async {
    await _db.collection('savings').doc(userId).delete();
  }
}
