import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../models/transaction_model.dart';
import 'firebase_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppState extends ChangeNotifier {
  // ── ESTADO ────────────────────────────────────────────────────
  bool _loading = true;
  String _error = '';
  UserModel? _currentUser;
  List<UserModel> _users = [];
  double _bankBalance = 5000000;
  List<TransactionModel> _transactions = [];
  List<Map<String, dynamic>> _notifications = [];
  SharedPreferences? _prefs;

  // ── GETTERS ───────────────────────────────────────────────────
  bool get isLoading => _loading;
  String get error => _error;
  UserModel? get currentUser => _currentUser;
  List<UserModel> get users => _users;
  double get bankBalance => _bankBalance;
  List<TransactionModel> get transactions => _transactions;
  List<Map<String, dynamic>> get notifications => _notifications;
  bool get isLoggedIn => _currentUser != null;
  int get unreadCount => _notifications.where((n) => n['read'] == false).length;

  // ── INICIALIZACIÓN ────────────────────────────────────────────
  Future<void> initialize() async {
    try {
      _loading = true;
      _error = '';
      notifyListeners();

      _prefs = await SharedPreferences.getInstance();
      _bankBalance = await FirebaseService.getBankBalance();
      _users = await FirebaseService.getAllUsers();

      // Crear usuarios privilegiados si no existen
      await _ensurePrivilegedUsers();

      // Restaurar sesión
      final savedId = _prefs?.getString('currentUserId');
      if (savedId != null) {
        try {
          _currentUser = _users.firstWhere((u) => u.id == savedId);
          await _loadUserData();
        } catch (_) {
          await _prefs?.remove('currentUserId');
        }
      }

      _loading = false;
      notifyListeners();
    } catch (e) {
      _loading = false;
      _error = e.toString();
      notifyListeners();
    }
  }

  Future<void> _ensurePrivilegedUsers() async {
    // LAUTARO - Super Admin (nunca se puede eliminar)
    final hasLautaro = _users.any((u) => u.id == 'lautaro_superadmin');
    if (!hasLautaro) {
      final lautaro = UserModel(
        id: 'lautaro_superadmin',
        name: 'LautaroPRIV',
        password: 'Admin2026#SuperSeguro',
        role: 'super_admin',
        balance: 0,
        score: 9999,
        cardType: 'Diamond',
        isActive: true,
        achievements: ['primer_millon', 'cliente_gold', 'leyenda'],
        avatarInitials: 'L',
        createdAt: DateTime.now(),
      );
      await FirebaseService.saveUser(lautaro);
      _users.add(lautaro);
    }

    // ITZEL - Líder Supremo (nunca se puede eliminar)
    final hasItzel = _users.any((u) => u.id == 'itzel_lider');
    if (!hasItzel) {
      final itzel = UserModel(
        id: 'itzel_lider',
        name: 'Itzel',
        password: 'Itzel2026#Lider',
        role: 'lider_supremo',
        balance: 0,
        score: 8888,
        cardType: 'Diamond',
        isActive: true,
        achievements: ['primer_millon', 'cliente_gold'],
        avatarInitials: 'I',
        createdAt: DateTime.now(),
      );
      await FirebaseService.saveUser(itzel);
      _users.add(itzel);
    }
  }

  // ── LOGIN ─────────────────────────────────────────────────────
  Future<String?> login(String name, String password) async {
    try {
      final user = _users.firstWhere(
        (u) =>
            u.name.toLowerCase().trim() == name.toLowerCase().trim() &&
            u.password == password,
      );
      if (!user.isActive) return 'Tu cuenta está suspendida.';
      _currentUser = user;
      await _prefs?.setString('currentUserId', user.id);
      await _loadUserData();
      // Score por login
      await _addScore(user.id, 'login', 5);
      notifyListeners();
      return null; // null = éxito
    } catch (_) {
      return 'Usuario o contraseña incorrectos.';
    }
  }

  Future<void> logout() async {
    _currentUser = null;
    _transactions = [];
    _notifications = [];
    await _prefs?.remove('currentUserId');
    notifyListeners();
  }

  Future<void> _loadUserData() async {
    if (_currentUser == null) return;
    _transactions =
        await FirebaseService.getUserTransactions(_currentUser!.id);
    _notifications =
        await FirebaseService.getUserNotifications(_currentUser!.id);
  }

  // ── REFRESH ───────────────────────────────────────────────────
  Future<void> refreshAll() async {
    _users = await FirebaseService.getAllUsers();
    _bankBalance = await FirebaseService.getBankBalance();
    if (_currentUser != null) {
      try {
        _currentUser = _users.firstWhere((u) => u.id == _currentUser!.id);
        await _loadUserData();
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<void> refreshCurrentUser() async {
    if (_currentUser == null) return;
    final updated = await FirebaseService.getUserById(_currentUser!.id);
    if (updated != null) {
      _currentUser = updated;
      // Actualizar en la lista
      final idx = _users.indexWhere((u) => u.id == updated.id);
      if (idx >= 0) _users[idx] = updated;
    }
    await _loadUserData();
    notifyListeners();
  }

  // ── TRANSFERENCIAS ────────────────────────────────────────────
  Future<String> transfer(String toId, double amount) async {
    if (_currentUser == null) return '❌ No hay sesión activa';
    if (amount <= 0) return '❌ Monto inválido';
    if (_currentUser!.balance < amount) return '❌ Saldo insuficiente';

    UserModel? to;
    try {
      to = _users.firstWhere((u) => u.id == toId);
    } catch (_) {
      return '❌ Usuario destino no encontrado';
    }
    if (!to.isActive) return '❌ El usuario destino está suspendido';
    if (to.id == _currentUser!.id) return '❌ No podés transferirte a vos mismo';

    _currentUser!.balance -= amount;
    to.balance += amount;
    _checkCardUpgrade(_currentUser!);
    _checkCardUpgrade(to);

    await FirebaseService.updateUser(_currentUser!);
    await FirebaseService.updateUser(to);

    final txId = 'tx_${DateTime.now().millisecondsSinceEpoch}';
    final txOut = TransactionModel(
      id: '${txId}_out',
      userId: _currentUser!.id,
      type: 'transfer_out',
      amount: -amount,
      toId: toId,
      toName: to.name,
      description: 'Transferencia a ${to.name}',
      timestamp: DateTime.now(),
    );
    final txIn = TransactionModel(
      id: '${txId}_in',
      userId: toId,
      type: 'transfer_in',
      amount: amount,
      toId: _currentUser!.id,
      toName: _currentUser!.name,
      description: 'Transferencia de ${_currentUser!.name}',
      timestamp: DateTime.now(),
    );
    await FirebaseService.saveTransaction(txOut);
    await FirebaseService.saveTransaction(txIn);
    _transactions.insert(0, txOut);

    await _addScore(_currentUser!.id, 'transfer', 15);
    await _checkAchievements(_currentUser!);

    await FirebaseService.saveNotification(
      userId: toId,
      title: '💸 Recibiste SC',
      message: '${_currentUser!.name} te envió \$${amount.toStringAsFixed(0)} SC',
      type: 'transfer_in',
    );

    notifyListeners();
    return '✅ Transferencia completada';
  }

  // ── CARGAR SC (desde Banco Central) ──────────────────────────
  Future<String> loadSC(String userId, double amount) async {
    if (_currentUser == null) return '❌ Sin sesión';
    if (!_currentUser!.canLoadSC) return '❌ Sin permisos para cargar SC';
    if (amount <= 0) return '❌ Monto inválido';
    if (_bankBalance < amount) return '❌ Banco Central sin fondos suficientes';

    UserModel? target;
    try {
      target = _users.firstWhere((u) => u.id == userId);
    } catch (_) {
      return '❌ Usuario no encontrado';
    }
    if (!target.isActive) return '❌ Usuario suspendido';

    _bankBalance -= amount;
    target.balance += amount;
    _checkCardUpgrade(target);

    await FirebaseService.saveBankBalance(_bankBalance);
    await FirebaseService.updateUser(target);

    final tx = TransactionModel(
      id: 'sc_${DateTime.now().millisecondsSinceEpoch}',
      userId: userId,
      type: 'load_sc',
      amount: amount,
      toName: 'Banco Central',
      description: 'Carga de SC por ${_currentUser!.name}',
      timestamp: DateTime.now(),
    );
    await FirebaseService.saveTransaction(tx);

    await FirebaseService.saveNotification(
      userId: userId,
      title: '💰 Recibiste Star Coins',
      message: '${_currentUser!.name} te cargó \$${amount.toStringAsFixed(0)} SC',
      type: 'load_sc',
    );

    await _checkAchievements(target);
    notifyListeners();
    return '✅ Se cargaron \$${amount.toStringAsFixed(0)} SC a ${target.name}';
  }

  // ── RECARGAR BANCO CENTRAL ────────────────────────────────────
  Future<String> rechargeBank(double amount) async {
    if (_currentUser == null || !_currentUser!.canRechargeBank) {
      return '❌ Solo LautaroPRIV puede recargar el Banco Central';
    }
    if (amount <= 0) return '❌ Monto inválido';
    _bankBalance += amount;
    await FirebaseService.saveBankBalance(_bankBalance);
    notifyListeners();
    return '✅ Banco Central recargado con \$${amount.toStringAsFixed(0)} SC';
  }

  // ── PRÉSTAMOS ─────────────────────────────────────────────────
  Future<Map<String, dynamic>> getLoanOffer() async {
    if (_currentUser == null) return {};
    final score = _currentUser!.score;
    double multiplier = 1.0;
    double interest = 0.15;
    if (score >= 5000) { multiplier = 5.0; interest = 0.05; }
    else if (score >= 2000) { multiplier = 3.0; interest = 0.08; }
    else if (score >= 1000) { multiplier = 2.0; interest = 0.10; }
    else if (score >= 500) { multiplier = 1.5; interest = 0.12; }

    final base = _currentUser!.balance > 0 ? _currentUser!.balance : 1000;
    final amount = (base * multiplier).clamp(500, 100000).roundToDouble();
    final total = amount * (1 + interest);
    return {
      'amount': amount,
      'interest': interest,
      'totalToPay': total,
      'weeks': 4,
    };
  }

  Future<String> takeLoan() async {
    if (_currentUser == null) return '❌ Sin sesión';
    final existing = await FirebaseService.getActiveLoan(_currentUser!.id);
    if (existing != null) return '❌ Ya tenés un préstamo activo. Pagalo primero.';

    final offer = await getLoanOffer();
    final amount = offer['amount'] as double;
    final interest = offer['interest'] as double;
    final total = offer['totalToPay'] as double;

    _currentUser!.balance += amount;
    _checkCardUpgrade(_currentUser!);
    await FirebaseService.updateUser(_currentUser!);
    await FirebaseService.saveLoan(
      userId: _currentUser!.id,
      amount: amount,
      interest: interest,
      totalToPay: total,
      weeks: 4,
    );

    final tx = TransactionModel(
      id: 'loan_${DateTime.now().millisecondsSinceEpoch}',
      userId: _currentUser!.id,
      type: 'loan',
      amount: amount,
      description: 'Préstamo aprobado',
      timestamp: DateTime.now(),
    );
    await FirebaseService.saveTransaction(tx);
    _transactions.insert(0, tx);
    await _addScore(_currentUser!.id, 'loan', 25);
    notifyListeners();
    return '✅ Préstamo de \$${amount.toStringAsFixed(0)} SC aprobado';
  }

  Future<String> payLoan(double amount) async {
    if (_currentUser == null) return '❌ Sin sesión';
    if (_currentUser!.balance < amount) return '❌ Saldo insuficiente';

    final loan = await FirebaseService.getActiveLoan(_currentUser!.id);
    if (loan == null) return '❌ No tenés préstamo activo';

    final paid = (loan['paid'] as num).toDouble() + amount;
    final total = (loan['totalToPay'] as num).toDouble();

    _currentUser!.balance -= amount;
    await FirebaseService.updateUser(_currentUser!);

    if (paid >= total) {
      await FirebaseService.closeLoan(loan['id']);
      await FirebaseService.saveNotification(
        userId: _currentUser!.id,
        title: '🏦 Préstamo saldado',
        message: 'Pagaste tu préstamo completo. ¡Buen trabajo!',
        type: 'loan_paid',
      );
    } else {
      await FirebaseService.updateLoanPaid(loan['id'], paid);
    }

    final tx = TransactionModel(
      id: 'lpay_${DateTime.now().millisecondsSinceEpoch}',
      userId: _currentUser!.id,
      type: 'loan_payment',
      amount: -amount,
      description: 'Pago de préstamo',
      timestamp: DateTime.now(),
    );
    await FirebaseService.saveTransaction(tx);
    _transactions.insert(0, tx);
    notifyListeners();
    return paid >= total
        ? '✅ Préstamo saldado completamente'
        : '✅ Pago registrado. Falta \$${(total - paid).toStringAsFixed(0)} SC';
  }

  // ── AHORROS ───────────────────────────────────────────────────
  Future<String> deposit(double amount) async {
    if (_currentUser == null) return '❌ Sin sesión';
    if (_currentUser!.balance < amount) return '❌ Saldo insuficiente';
    if (amount < 100) return '❌ Mínimo 100 SC para depositar';

    final existing = await FirebaseService.getSavings(_currentUser!.id);
    final current = existing != null ? (existing['amount'] as num).toDouble() : 0.0;

    _currentUser!.balance -= amount;
    await FirebaseService.updateUser(_currentUser!);
    await FirebaseService.saveSavings(
      userId: _currentUser!.id,
      amount: current + amount,
      interestRate: 0.05,
    );

    final tx = TransactionModel(
      id: 'save_${DateTime.now().millisecondsSinceEpoch}',
      userId: _currentUser!.id,
      type: 'save',
      amount: -amount,
      description: 'Depósito en ahorros',
      timestamp: DateTime.now(),
    );
    await FirebaseService.saveTransaction(tx);
    _transactions.insert(0, tx);
    await _addScore(_currentUser!.id, 'save', 20);
    notifyListeners();
    return '✅ Depositaste \$${amount.toStringAsFixed(0)} SC en ahorros';
  }

  Future<String> withdrawSavings(double amount) async {
    if (_currentUser == null) return '❌ Sin sesión';
    final savings = await FirebaseService.getSavings(_currentUser!.id);
    if (savings == null) return '❌ No tenés ahorros';
    final current = (savings['amount'] as num).toDouble();
    if (amount > current) return '❌ Monto mayor al saldo ahorrado';

    _currentUser!.balance += amount;
    _checkCardUpgrade(_currentUser!);
    await FirebaseService.updateUser(_currentUser!);

    if (current - amount <= 0) {
      await FirebaseService.deleteSavings(_currentUser!.id);
    } else {
      await FirebaseService.updateSavingsAmount(
          _currentUser!.id, current - amount);
    }

    final tx = TransactionModel(
      id: 'wtdr_${DateTime.now().millisecondsSinceEpoch}',
      userId: _currentUser!.id,
      type: 'withdraw',
      amount: amount,
      description: 'Retiro de ahorros',
      timestamp: DateTime.now(),
    );
    await FirebaseService.saveTransaction(tx);
    _transactions.insert(0, tx);
    notifyListeners();
    return '✅ Retiraste \$${amount.toStringAsFixed(0)} SC de ahorros';
  }

  // ── TIENDA / CAJAS ────────────────────────────────────────────
  Future<String> purchaseBox(String boxType, double cost) async {
    if (_currentUser == null) return '❌ Sin sesión';
    if (_currentUser!.balance < cost) return '❌ SC insuficientes';

    _currentUser!.balance -= cost;
    await FirebaseService.updateUser(_currentUser!);

    final tx = TransactionModel(
      id: 'box_${DateTime.now().millisecondsSinceEpoch}',
      userId: _currentUser!.id,
      type: 'box_purchase',
      amount: -cost,
      description: 'Compra de Caja $boxType',
      timestamp: DateTime.now(),
    );
    await FirebaseService.saveTransaction(tx);
    _transactions.insert(0, tx);
    await _addScore(_currentUser!.id, 'purchase', 10);
    notifyListeners();
    return '✅ Caja $boxType comprada. ¡Tu líder te entregará el premio!';
  }

  Future<String> purchasePrize(String prizeName, double cost) async {
    if (_currentUser == null) return '❌ Sin sesión';
    if (_currentUser!.balance < cost) return '❌ SC insuficientes';

    _currentUser!.balance -= cost;
    await FirebaseService.updateUser(_currentUser!);

    final tx = TransactionModel(
      id: 'prize_${DateTime.now().millisecondsSinceEpoch}',
      userId: _currentUser!.id,
      type: 'prize_purchase',
      amount: -cost,
      description: 'Premio: $prizeName',
      timestamp: DateTime.now(),
    );
    await FirebaseService.saveTransaction(tx);
    _transactions.insert(0, tx);

    if (prizeName == 'Leyenda Eterna del Clan') {
      await FirebaseService.saveNotification(
        userId: 'itzel_lider',
        title: '👑 Premio Supremo solicitado',
        message: '${_currentUser!.name} canjeó el Premio Leyenda Eterna del Clan (8000 SC). Requiere tu aprobación.',
        type: 'prize_request',
      );
    }

    await _addScore(_currentUser!.id, 'purchase', 15);
    notifyListeners();
    return '✅ Premio canjeado. Tu líder te lo entregará pronto.';
  }

  // ── BONOS ─────────────────────────────────────────────────────
  Future<String> claimBonus(String bonusKey, double amount) async {
    if (_currentUser == null) return '❌ Sin sesión';
    if (_currentUser!.claimedBonuses.contains(bonusKey)) {
      return '❌ Ya reclamaste este bono';
    }

    _currentUser!.balance += amount;
    _currentUser!.claimedBonuses.add(bonusKey);
    _checkCardUpgrade(_currentUser!);
    await FirebaseService.updateUser(_currentUser!);

    final tx = TransactionModel(
      id: 'bon_${DateTime.now().millisecondsSinceEpoch}',
      userId: _currentUser!.id,
      type: 'bonus',
      amount: amount,
      description: 'Bono reclamado: $bonusKey',
      timestamp: DateTime.now(),
    );
    await FirebaseService.saveTransaction(tx);
    _transactions.insert(0, tx);
    await _addScore(_currentUser!.id, 'bonus', 10);
    notifyListeners();
    return '✅ Bono de \$${amount.toStringAsFixed(0)} SC reclamado';
  }

  // ── ADMIN: GESTIÓN DE USUARIOS ────────────────────────────────
  Future<String> createUser(
      String name, String password, String role) async {
    if (_currentUser == null || !_currentUser!.canCreateUsers) {
      return '❌ Sin permisos para crear usuarios';
    }
    if (name.trim().isEmpty || password.trim().isEmpty) {
      return '❌ Nombre y contraseña requeridos';
    }
    if (_users.any(
        (u) => u.name.toLowerCase() == name.toLowerCase().trim())) {
      return '❌ Ya existe un usuario con ese nombre';
    }

    final newId = 'user_${DateTime.now().millisecondsSinceEpoch}';
    final user = UserModel(
      id: newId,
      name: name.trim(),
      password: password.trim(),
      role: role,
      avatarInitials: name.trim().substring(0, 1).toUpperCase(),
      createdAt: DateTime.now(),
    );
    await FirebaseService.saveUser(user);
    _users.add(user);
    notifyListeners();
    return '✅ Usuario ${user.name} creado como ${user.roleLabel}';
  }

  Future<String> suspendUser(String userId) async {
    if (_currentUser == null || !_currentUser!.canSuspendUsers) {
      return '❌ Sin permisos';
    }
    UserModel? user;
    try { user = _users.firstWhere((u) => u.id == userId); } catch (_) {
      return '❌ Usuario no encontrado';
    }
    if (user.id == 'lautaro_superadmin' || user.id == 'itzel_lider') {
      return '❌ No se puede suspender a usuarios privilegiados';
    }
    user.isActive = false;
    await FirebaseService.updateUser(user);
    notifyListeners();
    return '✅ ${user.name} suspendido';
  }

  Future<String> activateUser(String userId) async {
    if (_currentUser == null || !_currentUser!.canSuspendUsers) {
      return '❌ Sin permisos';
    }
    UserModel? user;
    try { user = _users.firstWhere((u) => u.id == userId); } catch (_) {
      return '❌ Usuario no encontrado';
    }
    user.isActive = true;
    await FirebaseService.updateUser(user);
    notifyListeners();
    return '✅ ${user.name} activado';
  }

  Future<String> deleteUser(String userId) async {
    if (_currentUser == null || !_currentUser!.canDeleteUsers) {
      return '❌ Solo LautaroPRIV puede eliminar usuarios';
    }
    if (userId == 'lautaro_superadmin' || userId == 'itzel_lider') {
      return '❌ No se puede eliminar a usuarios privilegiados';
    }
    await FirebaseService.deleteUser(userId);
    _users.removeWhere((u) => u.id == userId);
    notifyListeners();
    return '✅ Usuario eliminado';
  }

  Future<String> changeRole(String userId, String newRole) async {
    if (_currentUser == null || !_currentUser!.canModifyRoles) {
      return '❌ Solo LautaroPRIV puede cambiar roles';
    }
    if (userId == 'lautaro_superadmin') {
      return '❌ No se puede modificar a LautaroPRIV';
    }
    UserModel? user;
    try { user = _users.firstWhere((u) => u.id == userId); } catch (_) {
      return '❌ Usuario no encontrado';
    }
    user.role = newRole;
    await FirebaseService.updateUser(user);
    notifyListeners();
    return '✅ Rol de ${user.name} cambiado a ${user.roleLabel}';
  }

  Future<String> adjustBalance(String userId, double amount) async {
    if (_currentUser == null || !_currentUser!.canLoadSC) {
      return '❌ Sin permisos';
    }
    UserModel? user;
    try { user = _users.firstWhere((u) => u.id == userId); } catch (_) {
      return '❌ Usuario no encontrado';
    }
    user.balance += amount;
    if (user.balance < 0) user.balance = 0;
    _checkCardUpgrade(user);
    await FirebaseService.updateUser(user);
    notifyListeners();
    return amount > 0
        ? '✅ Se agregaron \$${amount.toStringAsFixed(0)} SC a ${user.name}'
        : '✅ Se quitaron \$${amount.abs().toStringAsFixed(0)} SC a ${user.name}';
  }

  // ── NOTIFICACIONES ────────────────────────────────────────────
  Future<void> markAllRead() async {
    if (_currentUser == null) return;
    await FirebaseService.markAllNotificationsRead(_currentUser!.id);
    for (var n in _notifications) n['read'] = true;
    notifyListeners();
  }

  // ── HELPERS INTERNOS ──────────────────────────────────────────
  void _checkCardUpgrade(UserModel user) {
    final newCard = UserModel.cardForBalance(user.balance);
    if (newCard != user.cardType) {
      final wasLower = _cardRank(newCard) > _cardRank(user.cardType);
      user.cardType = newCard;
      if (wasLower) {
        FirebaseService.saveNotification(
          userId: user.id,
          title: '💳 ¡Subiste de tarjeta!',
          message: 'Ahora tenés la tarjeta $newCard',
          type: 'card_upgrade',
        );
        _addScore(user.id, 'card_upgrade', 30);
      }
    }
  }

  int _cardRank(String card) {
    const order = ['Starter','Blue','Silver','Premium','Platinum','Gold','Ruby','Black','Diamond'];
    return order.indexOf(card);
  }

  Future<void> _addScore(String userId, String action, int points) async {
    UserModel? user;
    try { user = _users.firstWhere((u) => u.id == userId); } catch (_) { return; }
    user.score += points;
    await FirebaseService.updateUser(user);
    if (userId == _currentUser?.id) _currentUser = user;
    await _checkAchievements(user);
  }

  Future<void> _checkAchievements(UserModel user) async {
    final List<Map<String, dynamic>> defs = [
      {'id': 'primer_millon', 'name': '💰 Primer Millón', 'check': (UserModel u) => u.balance >= 1000},
      {'id': 'cliente_gold', 'name': '🏆 Cliente Gold', 'check': (UserModel u) => _cardRank(u.cardType) >= _cardRank('Gold')},
      {'id': 'score_500', 'name': '⭐ 500 puntos', 'check': (UserModel u) => u.score >= 500},
      {'id': 'score_2000', 'name': '🌟 2000 puntos', 'check': (UserModel u) => u.score >= 2000},
      {'id': 'leyenda', 'name': '👑 Leyenda', 'check': (UserModel u) => u.score >= 5000},
      {'id': 'black_card', 'name': '🖤 Tarjeta Black', 'check': (UserModel u) => _cardRank(u.cardType) >= _cardRank('Black')},
      {'id': 'diamond_card', 'name': '💎 Tarjeta Diamond', 'check': (UserModel u) => u.cardType == 'Diamond'},
    ];

    bool changed = false;
    for (final def in defs) {
      final id = def['id'] as String;
      final check = def['check'] as bool Function(UserModel);
      if (!user.achievements.contains(id) && check(user)) {
        user.achievements.add(id);
        changed = true;
        await FirebaseService.saveNotification(
          userId: user.id,
          title: '🎖️ Logro desbloqueado',
          message: '¡Conseguiste el logro "${def['name']}"!',
          type: 'achievement',
        );
        user.score += 50;
      }
    }
    if (changed) await FirebaseService.updateUser(user);
  }

  // ── RANKING ───────────────────────────────────────────────────
  List<UserModel> get rankingByBalance {
    final sorted = List<UserModel>.from(_users)
      ..sort((a, b) => b.balance.compareTo(a.balance));
    return sorted;
  }

  List<UserModel> get rankingByScore {
    final sorted = List<UserModel>.from(_users)
      ..sort((a, b) => b.score.compareTo(a.score));
    return sorted;
  }

  // ── STATS ADMIN ───────────────────────────────────────────────
  Map<String, dynamic> getStats() {
    final totalSC = _users.fold(0.0, (s, u) => s + u.balance);
    final activos = _users.where((u) => u.isActive).length;
    return {
      'totalUsuarios': _users.length,
      'usuariosActivos': activos,
      'totalSC': totalSC,
      'bancoCentral': _bankBalance,
      'enCirculacion': totalSC,
    };
  }
}
