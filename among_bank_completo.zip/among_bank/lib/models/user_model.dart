class UserModel {
  final String id;
  String name;
  String password;
  String role;
  double balance;
  double score;
  String cardType;
  bool isActive;
  List<String> achievements;
  List<String> claimedBonuses;
  String? avatarInitials;
  DateTime? createdAt;

  UserModel({
    required this.id,
    required this.name,
    required this.password,
    this.role = 'tripulante',
    this.balance = 0,
    this.score = 0,
    this.cardType = 'Starter',
    this.isActive = true,
    List<String>? achievements,
    List<String>? claimedBonuses,
    this.avatarInitials,
    this.createdAt,
  })  : achievements = achievements ?? [],
        claimedBonuses = claimedBonuses ?? [];

  // ROLES
  bool get isSuperAdmin => role == 'super_admin';
  bool get isLiderSupremo => role == 'lider_supremo' || isSuperAdmin;
  bool get isCoLider => role == 'colider' || isLiderSupremo;
  bool get isAdminElite => role == 'admin_elite' || isCoLider;
  bool get isAdmin => role == 'admin' || isAdminElite;
  bool get isTripulante => role == 'tripulante';

  // PERMISOS REALES
  bool get canCreateUsers => isLiderSupremo;
  bool get canLoadSC => isCoLider;
  bool get canTransfer => true;
  bool get canViewAdmin => isAdmin;
  bool get canModifyRoles => isSuperAdmin;
  bool get canSuspendUsers => isAdminElite;
  bool get canDeleteUsers => isSuperAdmin;
  bool get canViewBankCentral => isAdminElite;
  bool get canRechargeBank => isSuperAdmin;
  bool get canGivePremium => isLiderSupremo;

  String get roleLabel {
    switch (role) {
      case 'super_admin': return '👑 Líder Supremo';
      case 'lider_supremo': return '⭐ Líder';
      case 'colider': return '🔵 Co-Líder';
      case 'admin_elite': return '💜 Admin Elite';
      case 'admin': return '🟢 Admin';
      default: return '🚀 Tripulante';
    }
  }

  String get cardLabel => cardType;

  static String cardForBalance(double balance) {
    if (balance >= 500000) return 'Diamond';
    if (balance >= 250000) return 'Black';
    if (balance >= 100000) return 'Ruby';
    if (balance >= 50000) return 'Gold';
    if (balance >= 20000) return 'Platinum';
    if (balance >= 10000) return 'Premium';
    if (balance >= 5000) return 'Silver';
    if (balance >= 1000) return 'Blue';
    return 'Starter';
  }

  Map<String, dynamic> toMap() => {
        'name': name,
        'password': password,
        'role': role,
        'balance': balance,
        'score': score,
        'cardType': cardType,
        'isActive': isActive,
        'achievements': achievements,
        'claimedBonuses': claimedBonuses,
        'avatarInitials': avatarInitials ?? name.substring(0, 1).toUpperCase(),
        'createdAt': createdAt?.toIso8601String() ?? DateTime.now().toIso8601String(),
      };

  factory UserModel.fromMap(String id, Map<String, dynamic> data) => UserModel(
        id: id,
        name: data['name'] ?? '',
        password: data['password'] ?? '',
        role: data['role'] ?? 'tripulante',
        balance: (data['balance'] ?? 0).toDouble(),
        score: (data['score'] ?? 0).toDouble(),
        cardType: data['cardType'] ?? 'Starter',
        isActive: data['isActive'] ?? true,
        achievements: List<String>.from(data['achievements'] ?? []),
        claimedBonuses: List<String>.from(data['claimedBonuses'] ?? []),
        avatarInitials: data['avatarInitials'],
        createdAt: data['createdAt'] != null
            ? DateTime.tryParse(data['createdAt'])
            : null,
      );
}
