import 'package:flutter/material.dart';

// ── COLORES ───────────────────────────────────────────────────
const kGold = Color(0xFFFFD700);
const kGoldDark = Color(0xFFDAA520);
const kBg = Color(0xFF0A0A0A);
const kCard = Color(0xFF1A1A1A);
const kCard2 = Color(0xFF222222);

// ── GRADIENTES DE TARJETA ─────────────────────────────────────
LinearGradient cardGradient(String cardType) {
  switch (cardType) {
    case 'Diamond':
      return const LinearGradient(colors: [Color(0xFF00BFFF), Color(0xFF1E90FF)]);
    case 'Black':
      return const LinearGradient(colors: [Color(0xFF2C2C2C), Color(0xFF4A4A4A)]);
    case 'Ruby':
      return const LinearGradient(colors: [Color(0xFFB22222), Color(0xFFDC143C)]);
    case 'Gold':
      return const LinearGradient(colors: [Color(0xFFDAA520), Color(0xFFFFD700)]);
    case 'Platinum':
      return const LinearGradient(colors: [Color(0xFF708090), Color(0xFF9E9E9E)]);
    case 'Premium':
      return const LinearGradient(colors: [Color(0xFF6A0DAD), Color(0xFF9B59B6)]);
    case 'Silver':
      return const LinearGradient(colors: [Color(0xFF888888), Color(0xFFBBBBBB)]);
    case 'Blue':
      return const LinearGradient(colors: [Color(0xFF1565C0), Color(0xFF42A5F5)]);
    default:
      return const LinearGradient(colors: [Color(0xFF333333), Color(0xFF555555)]);
  }
}

Color cardTextColor(String cardType) {
  switch (cardType) {
    case 'Gold': return Colors.black;
    default: return Colors.white;
  }
}

// ── BOTÓN DORADO ──────────────────────────────────────────────
class GoldButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool loading;
  final IconData? icon;

  const GoldButton({
    super.key,
    required this.label,
    this.onTap,
    this.loading = false,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: loading ? null : onTap,
      child: Container(
        width: double.infinity,
        height: 52,
        decoration: BoxDecoration(
          gradient: onTap == null
              ? const LinearGradient(colors: [Colors.grey, Colors.grey])
              : const LinearGradient(colors: [kGold, kGoldDark]),
          borderRadius: BorderRadius.circular(14),
          boxShadow: onTap != null
              ? [BoxShadow(color: kGold.withOpacity(0.3), blurRadius: 12, spreadRadius: 2)]
              : null,
        ),
        child: loading
            ? const Center(child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (icon != null) ...[
                    Icon(icon, color: Colors.black, size: 20),
                    const SizedBox(width: 8),
                  ],
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

// ── TARJETA DE SECCIÓN ────────────────────────────────────────
class SectionCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;

  const SectionCard({super.key, required this.child, this.padding});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10),
      ),
      child: child,
    );
  }
}

// ── CAMPO DE TEXTO ────────────────────────────────────────────
class AmountField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String? hint;

  const AmountField({
    super.key,
    required this.controller,
    required this.label,
    this.hint,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.grey),
        prefixText: '\$ ',
        prefixStyle: const TextStyle(color: kGold, fontWeight: FontWeight.bold),
      ),
    );
  }
}

// ── ROW DE STAT ───────────────────────────────────────────────
class StatRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;

  const StatRow({super.key, required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.white60, fontSize: 13)),
          Text(value,
              style: TextStyle(
                  color: valueColor ?? Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 13)),
        ],
      ),
    );
  }
}

// ── MENSAJE SNACKBAR ──────────────────────────────────────────
void showMsg(BuildContext context, String msg, {bool isError = false}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.red[700] : const Color(0xFF1E6B1E),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ),
  );
}

// ── ROLE COLOR ────────────────────────────────────────────────
Color roleColor(String role) {
  switch (role) {
    case 'super_admin': return Colors.red;
    case 'lider_supremo': return kGold;
    case 'colider': return Colors.blue;
    case 'admin_elite': return Colors.purple;
    case 'admin': return Colors.green;
    default: return Colors.grey;
  }
}
